// H3-BatchShots v5.7：导演台右键「从分镜 txt 导入」
// 把分镜 txt（公共提示词块 + "### 镜头N 标题 | X秒" 分段）一次填进导演台的公共提示词和素材组。
// 走导演台自己的 editor.applyImportedTimeline（「导入导演包」用的同一个入口），不改导演台插件文件。
import { app } from "../../scripts/app.js";

const MENU_LABEL = "📋 从分镜 txt 导入（公共提示词 + 素材组）";

// ---------------------------------------------------------------- 解析
function miniMaxFrames(sec, fps = 24) {
    const n = Math.max(5, Math.round(Math.max(0.1, Number(sec) || 0.1) * fps));
    return n + ((((5 - (n % 17)) % 17) + 17) % 17);
}

export function parseStoryboard(text) {
    const src = String(text || "").replace(/\r\n?/g, "\n");
    let common = null;
    const cm = src.match(/^=+\s*公共提示词[^\n]*=+[ \t]*\n([\s\S]*?)\n=+\s*公共提示词结束\s*=+/m);
    if (cm) common = cm[1].trim();
    const head = /^###[ \t]*(.+?)[ \t]*[|｜][ \t]*([\d.]+)[ \t]*(?:秒|s|S)?[ \t]*$/gm;
    const marks = [];
    let m;
    while ((m = head.exec(src))) marks.push({ title: m[1].trim(), sec: parseFloat(m[2]), at: m.index, end: head.lastIndex });
    const groups = marks.map((mk, i) => {
        const body = src.slice(mk.end, i + 1 < marks.length ? marks[i + 1].at : src.length).trim();
        return { title: mk.title, sec: mk.sec, prompt: body };
    }).filter((g) => g.prompt && g.sec > 0);
    return { common, groups };
}

function continuityFor(prompt, i) {
    const p = prompt.toLowerCase();
    if (p.includes("[video continuation")) return true;
    if (i === 0) return false;
    if (p.includes("[reference generation]") || p.includes("[keyframe completion")) return false;
    return true;
}

// ---------------------------------------------------------------- 写进时间轴
function buildTimeline(tl, parsed, keepCommonRefs) {
    const t = JSON.parse(JSON.stringify(tl || {}));
    const fps = Number(t.frameRate || t.output?.frameRate || 24) || 24;
    const tmplSeg = (Array.isArray(t.segments) && t.segments[t.segments.length - 1]) || {};
    const tmplShot = (Array.isArray(t.shots) && t.shots[t.shots.length - 1]) || {};
    const tmplKf = (Array.isArray(t.keyframes) && t.keyframes[t.keyframes.length - 1]) || null;
    const stamp = Date.now().toString(36);
    let start = 0;
    const segs = [], shots = [], kfs = [];
    parsed.groups.forEach((g, i) => {
        const fc = miniMaxFrames(g.sec, fps);
        const id = `sb${stamp}${i}`;
        const cont = continuityFor(g.prompt, i);
        segs.push({
            ...tmplSeg, id, start, length: fc, frameCount: fc, durationSec: g.sec, prompt: g.prompt,
            negativePrompt: tmplSeg.negativePrompt ?? "", taskType: "", refs: [], refAudios: [], refVideos: [],
            genImage: { imageFile: "", fileName: "" }, startImage: null, endImage: null,
            continuityFromPrev: cont, loras: [],
        });
        shots.push({ ...tmplShot, id, durationSec: g.sec, prompt: g.prompt, negativePrompt: tmplShot.negativePrompt ?? "",
            startImage: null, endImage: null });
        if (tmplKf) kfs.push({ ...tmplKf, id, imageFile: "", width: 0, height: 0, start, length: fc, frameCount: fc,
            durationSec: g.sec, prompt: g.prompt });
        start += fc;
    });
    t.segments = segs;
    t.shots = shots;
    if (tmplKf) t.keyframes = kfs;
    t.totalFrames = start;
    t.durationSec = Math.round((start / fps) * 100) / 100;
    t.runSelectEnabled = false;
    t.runSelection = [];
    t.editMode = "segment";
    t.global = t.global || {};
    if (parsed.common != null) {
        t.global.prompt = parsed.common;
        t.global.commonEnabled = true;
    }
    if (!keepCommonRefs) {
        t.global.refs = [];
        t.global.refAudios = [];
        t.global.refVideos = [];
    }
    const key = String(t.global.taskType || "").split(" ")[0].trim();
    const ws = t.batchWorkspaces && key ? t.batchWorkspaces[key] : null;
    if (ws && typeof ws === "object") {
        ws.segments = JSON.parse(JSON.stringify(segs));
        ws.selectedIndex = 0;
        ws.editMode = "segment";
        ws.runSelectEnabled = false;
        ws.runSelection = [];
        if (ws.globalCommon && typeof ws.globalCommon === "object") {
            if (parsed.common != null) { ws.globalCommon.prompt = parsed.common; ws.globalCommon.commonEnabled = true; }
            if (!keepCommonRefs) { ws.globalCommon.refs = []; ws.globalCommon.refAudios = []; ws.globalCommon.refVideos = []; }
        }
    }
    return t;
}

// ---------------------------------------------------------------- 弹窗
function el(tag, css, text) {
    const e = document.createElement(tag);
    if (css) e.style.cssText = css;
    if (text != null) e.textContent = text;
    return e;
}

function openDialog(node) {
    const editor = node._minimaxEditor;
    if (!editor || typeof editor.applyImportedTimeline !== "function") {
        alert("导演台界面还没加载好（或导演台版本不支持导入），先把导演台节点展开显示一下再试。");
        return;
    }
    const mask = el("div", "position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:10000;display:flex;align-items:center;justify-content:center;");
    const box = el("div", "width:min(760px,92vw);max-height:88vh;display:flex;flex-direction:column;gap:10px;background:#1f1f23;color:#ddd;border:1px solid #444;border-radius:10px;padding:16px;font:13px/1.5 sans-serif;");
    box.append(el("div", "font-size:15px;font-weight:600;", "从分镜 txt 导入"));
    box.append(el("div", "color:#aaa;", "把分镜 txt 整个粘进来，或点「选择 txt 文件」。会识别「公共提示词」块和每个「### 镜头N 标题 | X秒」，说明区文字自动忽略。原来的素材组会被替换。"));
    const ta = el("textarea", "width:100%;height:46vh;resize:vertical;background:#111;color:#ddd;border:1px solid #444;border-radius:6px;padding:8px;font:12px/1.45 monospace;box-sizing:border-box;");
    ta.placeholder = "在这里粘贴分镜 txt …";
    const info = el("div", "color:#8fd18f;min-height:1.5em;", "");
    const row = el("div", "display:flex;gap:10px;align-items:center;flex-wrap:wrap;");
    const file = el("input"); file.type = "file"; file.accept = ".txt,.md,text/plain"; file.style.display = "none";
    const pick = el("button", "", "选择 txt 文件");
    const keepLab = el("label", "display:flex;gap:4px;align-items:center;cursor:pointer;");
    const keep = el("input"); keep.type = "checkbox"; keep.checked = true;
    keepLab.append(keep, el("span", "", "保留公共参数里已上传的参考图/音频"));
    const spacer = el("div", "flex:1");
    const cancel = el("button", "", "取消");
    const ok = el("button", "font-weight:600;", "导入");
    for (const b of [pick, cancel, ok]) b.style.cssText += "padding:6px 14px;border-radius:6px;border:1px solid #555;background:#2d2d33;color:#eee;cursor:pointer;";
    row.append(pick, file, keepLab, spacer, cancel, ok);
    box.append(ta, info, row);
    mask.append(box);
    document.body.append(mask);
    ta.focus();

    const close = () => mask.remove();
    const refresh = () => {
        const p = parseStoryboard(ta.value);
        if (!ta.value.trim()) { info.style.color = "#aaa"; info.textContent = ""; return p; }
        if (!p.groups.length) { info.style.color = "#e88"; info.textContent = "没找到「### 镜头N 标题 | X秒」开头的分段。"; return p; }
        const total = p.groups.reduce((s, g) => s + g.sec, 0);
        info.style.color = "#8fd18f";
        info.textContent = `识别到：公共提示词 ${p.common != null ? "✓" : "（没有，保持原样）"} · ${p.groups.length} 组 · 约 ${total} 秒`;
        return p;
    };
    ta.addEventListener("input", refresh);
    pick.onclick = () => file.click();
    file.onchange = async () => {
        const f = file.files?.[0];
        if (!f) return;
        ta.value = await f.text();
        refresh();
    };
    cancel.onclick = close;
    mask.addEventListener("keydown", (e) => { if (e.key === "Escape") close(); });
    ok.onclick = () => {
        const p = refresh();
        if (!p.groups.length) return;
        if (!confirm(`将用 ${p.groups.length} 组替换导演台现在的素材组，确定吗？`)) return;
        try {
            try { editor.commit?.(true, { syncTimeline: true }); } catch (_) { /* 先把界面上的改动存回去 */ }
            const w = editor.timelineWidget || node.widgets?.find((x) => x.name === "timeline_data");
            const cur = JSON.parse(w?.value || "{}");
            const next = buildTimeline(cur, p, keep.checked);
            editor.applyImportedTimeline(next, {});
            app.graph?.setDirtyCanvas?.(true, true);
            close();
            console.log(`[H3BatchShots] 分镜导入完成：${p.groups.length} 组`);
        } catch (err) {
            console.error("[H3BatchShots] 分镜导入失败", err);
            alert("导入失败：" + (err?.message || err));
        }
    };
}

// ---------------------------------------------------------------- 右键菜单
app.registerExtension({
    name: "H3BatchShots.StoryboardImport",
    async beforeRegisterNodeDef(nodeType, nodeData) {
        const name = nodeData?.name || "";
        if (name !== "MiniMaxH3Director" && name !== "ComfyMiniMaxH3Director") return;
        const orig = nodeType.prototype.getExtraMenuOptions;
        nodeType.prototype.getExtraMenuOptions = function (canvas, options) {
            const r = orig?.apply(this, arguments);
            options.unshift({ content: MENU_LABEL, callback: () => openDialog(this) }, null);
            return r;
        };
    },
});
