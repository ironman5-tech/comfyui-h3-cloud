// H3-BatchShots v5.9d：导演台「分组 LoRA」只看指定文件夹（默认文件夹名含 minimax）
// 把导演台 LoRA 面板的两个请求转到只扫指定文件夹的版本；其他节点（LoRA Manager、普通 LoraLoader）不受影响。
// 关键词在 custom_nodes/ComfyUI-H3-BatchShots/导演台LoRA只看这些文件夹.txt 里改，清空 = 显示全部。
import { api } from "../../scripts/api.js";

let _kwPromise = null;
function keywords() {
    if (!_kwPromise) {
        _kwPromise = api._h3bsOrigFetch("/h3bs/lora_filter")
            .then((r) => (r.ok ? r.json() : { keywords: [] }))
            .then((j) => (Array.isArray(j.keywords) ? j.keywords : []))
            .catch(() => []);
    }
    return _kwPromise;
}

function allowed(name, kws) {
    if (!kws.length) return true;
    const folders = String(name).replace(/\\/g, "/").split("/").slice(0, -1);
    return folders.some((p) => kws.some((k) => p.toLowerCase().includes(k)));
}

if (!api._h3bsOrigFetch) {
    const orig = api.fetchApi.bind(api);
    api._h3bsOrigFetch = orig;
    api.fetchApi = async function (route, options) {
        const r = String(route || "");
        if (r.startsWith("/minimax/director/lora_previews")) {
            _kwPromise = null; // 每次刷新时重新读关键词文件
            return orig("/h3bs/lora_previews", options);
        }
        if (r.startsWith("/object_info/LoraLoader") && String(new Error().stack || "").includes("minimax_segment_loras")) {
            const [res, kws] = await Promise.all([orig(route, options), keywords()]);
            if (!kws.length || !res.ok) return res;
            const j = await res.json();
            const opts = j?.LoraLoader?.input?.required?.lora_name;
            if (Array.isArray(opts?.[0])) opts[0] = opts[0].filter((n) => allowed(n, kws));
            return new Response(JSON.stringify(j), { status: 200, headers: { "Content-Type": "application/json" } });
        }
        return orig(route, options);
    };
}
