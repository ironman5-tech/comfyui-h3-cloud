"""MiniMax H3 连续镜头批量生成：分镜表 / 自动衔接 / 保存拼接清理。  版本 v5.5（v5.4 + 拼接节点说明.txt 会提醒“参考图/参考音频换过但这段没重跑”；v5.4 新增「H3 导演台分段拼接」节点，代码在 director_concat.py）"""

from __future__ import annotations

import gc
import logging
import math
import os
import re
import subprocess
import time
from fractions import Fraction

import torch

import comfy.model_management as mm
import folder_paths
from comfy_api.latest import ComfyExtension, InputImpl, Types, io, ui

log = logging.getLogger("H3BatchShots")

ROOT_SUBFOLDER = "H3分镜"
FPS = 24
CONTEXT_OPTIONS = ["22帧（约0.9秒）", "39帧（约1.6秒）", "90帧（约3.8秒）"]
HEADER_RE = re.compile(r"^\s*#{3,}\s*(.*)$")
SECONDS_RE = re.compile(r"(\d+(?:\.\d+)?)\s*(?:秒|s\b|S\b)")
# v3：标题里用 | 隔开写上这些词之一，这一镜就不接上一镜（换场景、切镜用）
NO_CONTEXT_MARKS = ("不衔接", "换场景", "切镜")
NO_CONTEXT_FREE = -1  # 传给自动衔接节点：这一镜不衔接、也不用首帧图，按提示词自由生成


# ----------------------------------------------------------------- helpers
def parse_shots(text: str, default_seconds: float):
    """Split the shot list. Each shot starts with a line beginning with ###.

    Header example:  ### 镜头1 | 6秒
    Text before the first ### is treated as notes and ignored.
    If there is no ### at all, the whole text is one shot.
    """
    lines = (text or "").replace("\r\n", "\n").split("\n")
    has_header = any(HEADER_RE.match(l) for l in lines)
    shots = []
    if not has_header:
        body = (text or "").strip()
        if body:
            shots.append({"title": "镜头1", "seconds": default_seconds, "prompt": body})
        return shots
    cur = None
    for line in lines:
        m = HEADER_RE.match(line)
        if m:
            if cur is not None:
                shots.append(cur)
            title = m.group(1).strip() or f"镜头{len(shots) + 1}"
            sm = SECONDS_RE.search(title)
            tokens = [t.strip() for t in re.split(r"[|｜]", title)]
            no_ctx = any(t in NO_CONTEXT_MARKS for t in tokens)
            seed_m = re.search(r"(?:种子|seed)\s*[=:：]?\s*(\d+)", title, re.I)
            cur = {"title": title, "seconds": float(sm.group(1)) if sm else default_seconds, "body": [],
                   "no_context": no_ctx, "seed": int(seed_m.group(1)) if seed_m else None}
        elif cur is not None:
            cur["body"].append(line)
    if cur is not None:
        shots.append(cur)
    out = []
    for s in shots:
        body = "\n".join(s.pop("body")).strip()
        if body:
            s["prompt"] = body
            out.append(s)
    return out


def snap_length(frames: int) -> int:
    """H3 frame grid: 17k + 5, rounded up."""
    frames = max(5, int(frames))
    k = math.ceil((frames - 5) / 17)
    return 17 * k + 5


def valid_clip_frames(n: int) -> int:
    """Largest 17k+5 <= n (AddGuide crops multi-frame guides to this grid)."""
    while n >= 5 and n % 17 != 5:
        n -= 1
    return n


def context_frames_from_option(opt: str) -> int:
    m = re.match(r"\s*(\d+)", opt or "")
    return int(m.group(1)) if m else 22


def safe_name(name: str) -> str:
    name = re.sub(r'[\\/:*?"<>|]+', "_", (name or "").strip()) or "未命名项目"
    return name[:60]


def project_dir(project: str) -> tuple[str, str]:
    # v4：project 可以是 “首帧图名/v2” 这种两级路径
    parts = [safe_name(x) for x in str(project or "").replace("\\", "/").split("/") if x.strip()] or [safe_name("")]
    sub = "/".join([ROOT_SUBFOLDER] + parts)
    full = os.path.join(folder_paths.get_output_directory(), ROOT_SUBFOLDER, *parts)
    os.makedirs(full, exist_ok=True)
    return full, sub


def _versions(base: str) -> list[int]:
    root = os.path.join(folder_paths.get_output_directory(), ROOT_SUBFOLDER, safe_name(base))
    if not os.path.isdir(root):
        return []
    return sorted(int(m.group(1)) for d in os.listdir(root)
                  if (m := re.fullmatch(r"v(\d+)", d)) and os.path.isdir(os.path.join(root, d)))


def resolve_version_folder(base: str, shot_index: int, version: int) -> tuple[str, str]:
    """v4：第1镜（版本=0 自动）新建 v(最大+1)；其他镜头用最新版本；版本>0 时固定用那个版本。"""
    vs = _versions(base)
    if version > 0:
        v, note = version, f"指定版本 v{version}"
    elif shot_index == 1 or not vs:
        v = (vs[-1] + 1) if vs else 1
        note = f"新建版本 v{v}" + ("" if shot_index == 1 else "（没找到旧版本，只好新建）")
    else:
        v, note = vs[-1], f"接着用最新版本 v{vs[-1]}"
    proj = f"{safe_name(base)}/v{v}"
    project_dir(proj)
    return proj, note


def first_frame_name(prompt, unique_id, input_name="size_image") -> str:
    """v4：顺着连线找到“加载图像”节点，取首帧图文件名（不含扩展名）。找不到返回空。"""
    try:
        node = prompt[str(unique_id)]
        link = node["inputs"].get(input_name)
        for _ in range(8):
            if not isinstance(link, list):
                return ""
            src = prompt[str(link[0])]
            ins = src.get("inputs", {})
            img = ins.get("image")
            if isinstance(img, str):
                return os.path.splitext(os.path.basename(img.split(" [")[0]))[0]
            link = img if isinstance(img, list) else next((v for v in ins.values() if isinstance(v, list)), None)
    except Exception:
        pass
    return ""


DIALOG_RE = re.compile(r"<d>\s*(?:\[[^\]]*\]\s*)?(.*?)</d>", re.S)


def dialog_lines(prompt_text: str) -> list[str]:
    return [re.sub(r"\s+", " ", m).strip() for m in DIALOG_RE.findall(prompt_text or "") if m.strip()]


PUNCT_SPLIT = "，。！？；：、,.!?;:…"


def split_caption(text: str, max_len: int = 14) -> list[str]:
    """v4.1：按标点切成一句一条；句末的逗号句号去掉（字幕规范），！？保留；太短的小句并到下一句，用空格隔开。"""
    raw = [p.strip() for p in re.split(r"(?<=[" + PUNCT_SPLIT + r"])", text or "") if p.strip()]
    out = []
    for p in raw:
        keep = p[-1] if p[-1] in "！？!?" else ""
        body = p.rstrip(PUNCT_SPLIT).strip()
        if not body:
            continue
        piece = body + keep
        if out and (len(out[-1]) < 4 or len(piece) < 3) and len(out[-1]) + 1 + len(piece) <= max_len:
            out[-1] = out[-1] + " " + piece
        else:
            out.append(piece)
    return out


def load_mono_16k(path: str):
    """用 ffmpeg 把视频里的声音读成 16kHz 单声道 numpy 数组。"""
    import numpy as np
    import imageio_ffmpeg
    exe = imageio_ffmpeg.get_ffmpeg_exe()
    r = subprocess.run([exe, "-v", "error", "-i", path, "-vn", "-ac", "1", "-ar", "16000", "-f", "s16le", "-"],
                       capture_output=True, timeout=300)
    if r.returncode != 0 or not r.stdout:
        return None
    return np.frombuffer(r.stdout, dtype=np.int16).astype("float32") / 32768.0


def speech_spans(x, sr: int = 16000):
    """v4.1：简单人声检测。只看 250-3500Hz 人声频段的能量，返回 [(开始秒, 结束秒), ...] 的小片段。"""
    import numpy as np
    from scipy.signal import butter, sosfilt
    if x is None or len(x) < sr // 2:
        return []
    y = sosfilt(butter(4, [250, 3500], btype="bandpass", fs=sr, output="sos"), x)
    win, hop = int(0.02 * sr), int(0.01 * sr)
    n = 1 + max(0, (len(y) - win) // hop)
    idx = np.arange(win)[None, :] + hop * np.arange(n)[:, None]
    db = 10 * np.log10(np.mean(y[idx] ** 2, axis=1) + 1e-10)
    db = np.convolve(db, np.ones(5) / 5, mode="same")
    floor, peak = np.percentile(db, 20), np.percentile(db, 98)
    if peak - floor < 8:
        return []
    voiced = db > max(floor + 6, floor + 0.35 * (peak - floor))
    spans, start = [], None
    for i, v in enumerate(voiced):
        t = i * hop / sr
        if v and start is None:
            start = t
        elif not v and start is not None:
            spans.append([start, t])
            start = None
    if start is not None:
        spans.append([start, n * hop / sr])
    merged = []
    for a, b in spans:
        if merged and a - merged[-1][1] < 0.18:
            merged[-1][1] = b
        else:
            merged.append([a, b])
    return [(a, b) for a, b in merged if b - a >= 0.12]


def utterances(spans, n_lines: int):
    """把小片段按 0.6 秒以内的停顿连成“一句话”，挑最长的 n_lines 句（按时间顺序）。"""
    groups = []
    for a, b in spans:
        if groups and a - groups[-1][-1][1] < 0.6:
            groups[-1].append((a, b))
        else:
            groups.append([(a, b)])
    groups.sort(key=lambda g: -sum(b - a for a, b in g))
    return sorted(groups[:max(1, n_lines)], key=lambda g: g[0][0])


def place_pieces(pieces, group):
    """在一句话的人声范围里排几条字幕：按字数比例找切点，再吸附到最近的停顿处。"""
    a0, b0 = group[0][0], group[-1][1]
    gaps = [((group[i][1] + group[i + 1][0]) / 2) for i in range(len(group) - 1)]
    total = sum(len(p) for p in pieces) or 1
    cuts, acc = [], 0
    for p in pieces[:-1]:
        acc += len(p)
        guess = a0 + (b0 - a0) * acc / total
        near = [g for g in gaps if abs(g - guess) <= 0.45 and (not cuts or g > cuts[-1] + 0.3)]
        cuts.append(min(near, key=lambda g: abs(g - guess)) if near else guess)
    bounds = [a0] + cuts + [b0]
    return [(bounds[i], bounds[i + 1], p) for i, p in enumerate(pieces)]


def srt_time(t: float) -> str:
    t = max(0.0, t)
    h, rem = divmod(int(round(t * 1000)), 3600000)
    m, rem = divmod(rem, 60000)
    sec, ms = divmod(rem, 1000)
    return f"{h:02d}:{m:02d}:{sec:02d},{ms:03d}"


def shot_path(project: str, idx: int) -> str:
    full, _ = project_dir(project)
    return os.path.join(full, f"shot_{idx:03d}.mp4")


TailLock_T = io.Custom("H3_TAIL_LOCK")
REPAIR_MODES = ["正常（往后接着跑）", "只修这一段（锁住结尾，后面不动）"]
TAIL_LOCK_OPTIONS = ["22帧（约0.9秒，最稳）", "5帧（约0.2秒，改动空间大）"]


def free_all_memory(tag: str):
    try:
        mm.unload_all_models()
        mm.soft_empty_cache(True)
    except Exception as e:  # pragma: no cover
        log.warning("[H3BatchShots] free memory failed: %s", e)
    gc.collect()
    try:
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            torch.cuda.ipc_collect()
    except Exception:
        pass
    print(f"[H3BatchShots] {tag}：已卸载模型并清理显存/内存")


def _node_output_first(out):
    args = getattr(out, "args", None)
    if args is None:
        args = out["result"] if isinstance(out, dict) else out
    return args[0]


def get_core_node(name: str):
    import nodes as comfy_nodes
    return comfy_nodes.NODE_CLASS_MAPPINGS.get(name)


# ----------------------------------------------------------------- 1. shot list
class H3BatchShotList(io.ComfyNode):
    @classmethod
    def define_schema(cls):
        return io.Schema(
            node_id="H3BatchShotList",
            display_name="H3 分镜表（批量）",
            category="H3 连续镜头批量",
            description="按镜头序号取出当前镜头。批次数量设为镜头数、序号设为“每次+1”，点一次运行就会依次跑完全部镜头。",
            inputs=[
                io.String.Input("project", default="", tooltip="留空＝用首帧图文件名做文件夹名。每次从第1镜开始跑，会自动新建 v1、v2… 版本文件夹，不会覆盖。"),
                io.String.Input("shots", multiline=True, default="### 镜头1 | 6秒\n在这里写第一镜的提示词\n\n### 镜头2 | 6秒\n第二镜……",
                                tooltip="每个镜头以 ### 开头的一行作为标题，标题里写“6秒”就是该镜时长。换场景/切镜的那一镜，标题末尾加“| 不衔接”。"),
                io.Int.Input("shot_index", default=1, min=1, max=999, control_after_generate=io.ControlAfterGenerate.increment,
                             tooltip="当前跑第几镜。后面的“increment”表示每排一次队自动 +1；想重跑某一镜就改成 fixed 并填序号。"),
                io.Float.Input("default_seconds", default=6.0, min=2.0, max=15.0, step=0.5, tooltip="标题里没写秒数时用这个时长"),
                io.Boolean.Input("use_context", default=True, label_on="衔接上一镜", label_off="每镜独立",
                                 tooltip="打开：第2镜起自动接上一镜结尾，画面声音无缝。关闭：每镜都从首帧图独立开始。"),
                io.Combo.Input("context", options=CONTEXT_OPTIONS, default=CONTEXT_OPTIONS[0],
                               tooltip="用上一镜结尾多少帧做衔接。越长越连贯，但每镜多算这些帧、更吃显存。"),
                io.Float.Input("megapixels", default=0.6, min=0.2, max=2.0, step=0.05,
                               tooltip="画面大小（百万像素）。4060Ti 16G：0.6 稳，0.7 接近上限。比例自动跟首帧图一致。"),
                io.Int.Input("base_seed", default=20261009, min=0, max=0xFFFFFFFF, tooltip="每镜种子 = 这个数 + 镜头序号，结果可复现"),
                io.Image.Input("size_image", optional=True, tooltip="接首帧图，画面比例跟它一致；不接就用 16:9"),
                io.String.Input("trigger_words", optional=True, force_input=True, tooltip="接 LoRA Manager 的触发词，会自动加在每镜提示词最前面"),
                io.Int.Input("version", default=0, min=0, max=999,
                             tooltip="0＝自动：从第1镜开始跑就新建一个版本文件夹，其他镜头放进最新版本。要修改旧版本里的某一镜，就填那个版本号。"),
            ],
            hidden=[io.Hidden.prompt, io.Hidden.unique_id],
            outputs=[
                io.String.Output("prompt", display_name="提示词"),
                io.Int.Output("width", display_name="宽"),
                io.Int.Output("height", display_name="高"),
                io.Int.Output("length", display_name="帧数"),
                io.Int.Output("seed", display_name="种子"),
                io.Int.Output("shot_index", display_name="镜头序号"),
                io.Int.Output("context_frames", display_name="衔接帧数"),
                io.String.Output("project", display_name="项目名"),
                io.String.Output("info", display_name="信息"),
            ],
        )

    @classmethod
    def fingerprint_inputs(cls, **kwargs):
        return time.time()  # v4：每次都重新判断版本文件夹

    @classmethod
    def execute(cls, project, shots, shot_index, default_seconds, use_context, context, megapixels, base_seed,
                size_image=None, trigger_words=None, version=0):
        parsed = parse_shots(shots, default_seconds)
        total = len(parsed)
        if total == 0:
            raise ValueError("分镜表是空的：请在 shots 里写提示词，每个镜头用 ### 开头的一行分隔。")
        if shot_index > total:
            raise ValueError(f"✅ 全部 {total} 个镜头已经跑完（当前序号 {shot_index}）。"
                             f"后面多排的任务会在这里停下，可以忽略。要重新开始，把镜头序号改回 1。")
        shot = parsed[shot_index - 1]

        ctx = 0
        ctx_out = 0
        cut_here = bool(shot.get("no_context")) and shot_index > 1
        if use_context and shot_index > 1 and not cut_here:
            ctx = valid_clip_frames(context_frames_from_option(context))
            ctx_out = ctx
        elif cut_here:
            ctx_out = NO_CONTEXT_FREE
        length = snap_length(round(shot["seconds"] * FPS) + ctx)

        if size_image is not None:
            h0, w0 = int(size_image.shape[1]), int(size_image.shape[2])
            ar = w0 / max(h0, 1)
        else:
            ar = 16 / 9
        area = megapixels * 1024 * 1024
        w = max(256, int(round(math.sqrt(area * ar) / 32)) * 32)
        h = max(256, int(round(math.sqrt(area / ar) / 32)) * 32)

        prompt = shot["prompt"]
        tw = ", ".join(w.strip() for w in re.split(r",+", trigger_words or "") if w.strip())
        if tw:
            prompt = f"{tw}\n{prompt}"

        base = (project or "").strip() or first_frame_name(cls.hidden.prompt, cls.hidden.unique_id) or "未命名项目"
        project, ver_note = resolve_version_folder(base, int(shot_index), int(version or 0))
        if shot.get("seed") is not None:
            seed = int(shot["seed"]) % 0x100000000
        else:
            seed = (int(base_seed) + int(shot_index)) % 0x100000000
        new_sec = (length - ctx) / FPS
        info = (f"项目「{project}」（{ver_note}） 镜头 {shot_index}/{total}：{shot['title']}\n"
                f"尺寸 {w}×{h}，生成 {length} 帧（衔接 {ctx} 帧 + 新内容约 {new_sec:.1f} 秒），种子 {seed}")
        if cut_here:
            info += "\n✂️ 这一镜标了“不衔接”：不接上一镜，从这里硬切（换场景/切镜）。"
        if length > 362:
            info += "\n⚠️ 帧数超过 362（约15秒），H3 没训练过这么长，可能变差或爆显存。"
        print("[H3BatchShots] " + info.replace("\n", " | "))
        return io.NodeOutput(prompt, w, h, length, seed, shot_index, ctx_out, project, info, ui={"text": [info]})


# ----------------------------------------------------------------- 2. auto guide
class H3BatchAutoGuide(io.ComfyNode):
    @classmethod
    def define_schema(cls):
        return io.Schema(
            node_id="H3BatchAutoGuide",
            display_name="H3 自动衔接（首帧/上一镜）",
            category="H3 连续镜头批量",
            description="第1镜：把首帧图钉在第0帧。第2镜起：自动读取上一镜结尾的画面和声音，钉在开头，实现无缝衔接。",
            inputs=[
                io.Conditioning.Input("positive"),
                io.Latent.Input("latent"),
                io.Vae.Input("vae"),
                io.Vae.Input("audio_vae"),
                io.String.Input("project", force_input=True),
                io.Int.Input("shot_index", force_input=True),
                io.Int.Input("context_frames", force_input=True),
                io.Image.Input("first_frame", optional=True, tooltip="第1镜的首帧图"),
                io.Boolean.Input("use_first_frame", default=True, label_on="第1镜用首帧图", label_off="第1镜自由生成"),
                io.Float.Input("context_noise", default=0.1, min=0.0, max=0.5, step=0.01,
                               tooltip="给衔接帧加一点噪声，减少接缝闪烁（参考工作流作者推荐 0.1）"),
                io.Boolean.Input("use_audio_context", default=True, label_on="声音也衔接", label_off="只衔接画面"),
                io.Combo.Input("repair_mode", options=REPAIR_MODES, default=REPAIR_MODES[0],
                               tooltip="只修这一段：开头照常接上一段，结尾钉住这一段旧视频的最后一小段（画面+声音），"
                                       "新生成的结尾会落回原来的样子，后面的段不用重跑。用时：版本号填要改的版本，镜头序号填这一段并改成固定，批次数 1。"),
                io.Combo.Input("tail_lock_frames", options=TAIL_LOCK_OPTIONS, default=TAIL_LOCK_OPTIONS[0],
                               tooltip="锁住旧结尾多长。22 帧和段与段的衔接一样长，最稳；5 帧只锁最后的位置和动作趋势，中间能改得更多。"),
                io.Int.Input("audio_feather_ticks", default=12, min=0, max=64,
                             tooltip="声音接缝羽化（需要已安装 Audio-Guide-Feather 插件），0 = 不羽化"),
            ],
            outputs=[
                io.Conditioning.Output("positive"),
                io.Int.Output("crop_frames", display_name="要裁掉的衔接帧"),
                io.Image.Output("color_ref", display_name="对色参考"),
                TailLock_T.Output(display_name="结尾锁定"),
            ],
        )

    @classmethod
    def fingerprint_inputs(cls, **kwargs):
        return time.time()  # 上一镜文件可能被重跑覆盖，每次都重新读取

    @classmethod
    def execute(cls, positive, latent, vae, audio_vae, project, shot_index, context_frames,
                first_frame=None, use_first_frame=True, context_noise=0.1, use_audio_context=True, audio_feather_ticks=12,
                repair_mode=REPAIR_MODES[0], tail_lock_frames=TAIL_LOCK_OPTIONS[0]):
        head = cls._head(positive, latent, vae, audio_vae, project, shot_index, context_frames, first_frame,
                         use_first_frame, context_noise, use_audio_context, audio_feather_ticks)
        pos, n_head, color_ref = head.args if hasattr(head, "args") else head
        lock = None
        if repair_mode == REPAIR_MODES[1]:
            pos, lock = cls._tail(pos, latent, vae, audio_vae, project, int(shot_index), int(n_head),
                                  context_frames_from_option(tail_lock_frames), use_audio_context)
            lock = dict(lock or {"frames": None})
            lock["repair"] = True
        return io.NodeOutput(pos, n_head, color_ref, lock)

    @classmethod
    def _tail(cls, positive, latent, vae, audio_vae, project, shot_index, n_head, want, use_audio):
        """v5.1：把这一段旧视频的最后 n 帧（和声音）钉在新视频结尾。"""
        import json
        from comfy_extras.nodes_minimax_h3 import MiniMaxH3AddGuide
        cur, nxt = shot_path(project, shot_index), shot_path(project, shot_index + 1)
        if not os.path.isfile(cur):
            print(f"[H3BatchShots] ⚠️ 修复模式：这个版本文件夹里没有第 {shot_index} 段，没有旧结尾可锁，按正常方式生成。"
                  f"修复时“版本号”要填要修的那一版（填 0 会被当成新的一批，第 1 段还会新建版本文件夹）")
            return positive, None
        if not os.path.isfile(nxt):
            print(f"[H3BatchShots] 修复模式：第 {shot_index} 段后面没有下一段，不用锁结尾")
            return positive, None
        try:
            with open(nxt.replace(".mp4", ".json"), encoding="utf-8") as f:
                next_ctx = int(json.load(f).get("context_frames", 0) or 0)
        except Exception:
            next_ctx = 22
        if next_ctx <= 0:
            print(f"[H3BatchShots] 修复模式：第 {shot_index + 1} 段是“不衔接”，不依赖这一段的结尾，不用锁")
            return positive, None
        comp = InputImpl.VideoFromFile(cur).get_components()
        frames = comp.images
        n = valid_clip_frames(min(int(want), int(frames.shape[0])))
        video = latent["samples"].tensors[0]
        total = sum((1, 4, 4, 4, 4)[k % 5] for k in range(video.shape[2]))
        if n_head + n + 24 > total:
            print(f"[H3BatchShots] ⚠️ 修复模式：这一段太短（{total} 帧），放不下开头 {n_head} 帧 + 结尾 {n} 帧，跳过结尾锁定")
            return positive, None
        tail = frames[-n:].clone().float()
        aud = None
        if use_audio and comp.audio is not None:
            wav, sr = comp.audio["waveform"], int(comp.audio["sample_rate"])
            fr = float(comp.frame_rate) if comp.frame_rate else FPS
            k = int(round(n / fr * sr))
            if wav.shape[-1] >= k > 0:
                aud = {"waveform": wav[..., -k:].contiguous(), "sample_rate": sr}
        positive = _node_output_first(MiniMaxH3AddGuide.execute(
            positive=positive, latent=latent, frame_idx=-n, vae=vae, audio_vae=audio_vae, image=tail, audio=aud))
        print(f"[H3BatchShots] 修复模式：第 {shot_index} 段开头接第 {shot_index - 1} 段，结尾钉住旧视频最后 {n} 帧"
              f"（声音{'有' if aud is not None else '无'}），第 {shot_index + 1} 段之后都不用重跑")
        return positive, {"frames": tail, "audio": aud, "n": n, "next_mtime": os.path.getmtime(nxt)}

    @classmethod
    def _head(cls, positive, latent, vae, audio_vae, project, shot_index, context_frames,
              first_frame=None, use_first_frame=True, context_noise=0.1, use_audio_context=True, audio_feather_ticks=12):
        from comfy_extras.nodes_minimax_h3 import MiniMaxH3AddGuide

        if context_frames is not None and context_frames < 0:
            print(f"[H3BatchShots] 镜头{shot_index}：标了“不衔接”，硬切，按提示词自由生成（不用首帧图）")
            return io.NodeOutput(positive, 0, None)

        if context_frames and context_frames > 0 and shot_index > 1:
            prev = shot_path(project, shot_index - 1)
            if not os.path.isfile(prev):
                raise FileNotFoundError(
                    f"找不到上一镜的视频：{prev}\n请先跑完第 {shot_index - 1} 镜；或者在分镜表里关掉“衔接上一镜”。")
            comp = InputImpl.VideoFromFile(prev).get_components()
            frames = comp.images
            n = valid_clip_frames(min(int(context_frames), int(frames.shape[0])))
            if n < 5:
                raise ValueError(f"上一镜只有 {frames.shape[0]} 帧，不够做衔接。")
            ctx = frames[-n:].clone().float()
            if context_noise > 0 and n > 1:
                g = torch.Generator(device="cpu").manual_seed(int(shot_index))
                noise = torch.randn(ctx[:-1].shape, generator=g, dtype=torch.float32)
                ctx[:-1] = (ctx[:-1] + context_noise * noise).clamp(0.0, 1.0)
            audio = None
            if use_audio_context and comp.audio is not None:
                wav = comp.audio["waveform"]
                sr = int(comp.audio["sample_rate"])
                fr = float(comp.frame_rate) if comp.frame_rate else FPS
                samples = int(round(n / fr * sr))
                if wav.shape[-1] >= samples > 0:
                    audio = {"waveform": wav[..., -samples:].contiguous(), "sample_rate": sr}
            positive = _node_output_first(MiniMaxH3AddGuide.execute(
                positive=positive, latent=latent, frame_idx=0, vae=vae, audio_vae=audio_vae, image=ctx, audio=audio))
            if audio is not None and audio_feather_ticks > 0:
                feather = get_core_node("MiniMaxH3AudioGuideFeather")
                if feather is not None:
                    positive = _node_output_first(feather.execute(positive=positive, audio_feather_ticks=int(audio_feather_ticks)))
                else:
                    print("[H3BatchShots] 没装 Audio-Guide-Feather 插件，跳过声音羽化")
            print(f"[H3BatchShots] 镜头{shot_index}：已衔接上一镜结尾 {n} 帧（声音{'有' if audio is not None else '无'}）")
            # v2：把上一镜结尾的 n 帧原样（不加噪）交给保存节点，用来对色、找最佳接缝点
            return io.NodeOutput(positive, n, frames[-n:].clone().float())

        if use_first_frame and first_frame is not None:
            positive = _node_output_first(MiniMaxH3AddGuide.execute(
                positive=positive, latent=latent, frame_idx=0, vae=vae, audio_vae=audio_vae, image=first_frame[:1], audio=None))
            print(f"[H3BatchShots] 镜头{shot_index}：使用首帧图")
            return io.NodeOutput(positive, 0, first_frame[:1])

        print(f"[H3BatchShots] 镜头{shot_index}：不用首帧，自由生成")
        return io.NodeOutput(positive, 0, None)


# ----------------------------------------------------------------- 3. save + concat + cleanup
COLOR_METHODS = ["重叠段整体对色（推荐）", "mkl_lab", "reinhard_lab", "histogram"]
SEAM_MODES = ["自动找最佳接缝点（推荐）", "固定在衔接末尾（v1做法）"]
SUBTITLE_MODES = ["烧进画面 + 出 srt 文件", "只出 srt 文件", "关闭"]


def _proxy(x):
    """Small proxy for cheap frame comparison. x: [B,H,W,C] 0..1"""
    sh = max(1, x.shape[1] // 64)
    sw = max(1, x.shape[2] // 64)
    return x[:, ::sh, ::sw, :3].float()


def _fit(frames, h, w):
    if frames.shape[1] == h and frames.shape[2] == w:
        return frames.float()
    t = torch.nn.functional.interpolate(frames.float().permute(0, 3, 1, 2), size=(h, w), mode="bilinear", align_corners=False)
    return t.permute(0, 2, 3, 1)


def _lab_stats(frames, chunk=8):
    import kornia
    s = torch.zeros(3, dtype=torch.float64)
    ss = torch.zeros(3, dtype=torch.float64)
    n = 0
    for i in range(0, frames.shape[0], chunk):
        lab = kornia.color.rgb_to_lab(frames[i:i + chunk].float().permute(0, 3, 1, 2).clamp(0, 1))
        flat = lab.permute(1, 0, 2, 3).reshape(3, -1).double()
        s += flat.sum(1)
        ss += (flat * flat).sum(1)
        n += flat.shape[1]
    mean = s / n
    std = (ss / n - mean * mean).clamp_min(1e-6).sqrt()
    return mean.float(), std.float()


def overlap_color_match(images, gen_ctx, prev_ctx, strength=1.0, chunk=8):
    """Match the whole new clip to the previous clip, using the overlap frames
    (same moment in time, same content) to measure the color difference.
    Lab mean/std transfer, clamped so it can never go wild."""
    import kornia
    mu_g, sd_g = _lab_stats(gen_ctx)
    mu_p, sd_p = _lab_stats(prev_ctx)
    ratio = (sd_p / sd_g).clamp(0.75, 1.33).view(1, 3, 1, 1)
    shift = (mu_p - mu_g).clamp(torch.tensor([-15.0, -10.0, -10.0]), torch.tensor([15.0, 10.0, 10.0]))
    mu_g4 = mu_g.view(1, 3, 1, 1)
    target_mean = (mu_g + shift).view(1, 3, 1, 1)
    out = torch.empty_like(images, dtype=torch.float32)
    for i in range(0, images.shape[0], chunk):
        x = images[i:i + chunk].float().clamp(0, 1).permute(0, 3, 1, 2)
        lab = kornia.color.rgb_to_lab(x)
        new = (lab - mu_g4) * ratio + target_mean
        lab = lab + float(strength) * (new - lab)
        out[i:i + chunk] = kornia.color.lab_to_rgb(lab).clamp(0, 1).permute(0, 2, 3, 1)
    print(f"[H3BatchShots] 重叠段对色：ΔL={float(shift[0]):+.2f} Δa={float(shift[1]):+.2f} Δb={float(shift[2]):+.2f}")
    return out


def _box_blur(x, k):
    """x: [B,H,W,C] -> low-frequency version"""
    k = int(k) | 1
    pad = k // 2
    t = x.permute(0, 3, 1, 2)
    pad_h = min(pad, t.shape[2] - 1)
    pad_w = min(pad, t.shape[3] - 1)
    t = torch.nn.functional.pad(t, (pad_w, pad_w, pad_h, pad_h), mode="reflect")
    t = torch.nn.functional.avg_pool2d(t, kernel_size=(2 * pad_h + 1, 2 * pad_w + 1), stride=1)
    return t.permute(0, 2, 3, 1)


def _splice_audio(new, old_tail, cut_s: float, old_from_s: float, fade_s: float = 0.012):
    """新声音取到 cut_s，后面接旧结尾声音（从 old_from_s 开始），接口处 12ms 交叉淡化。"""
    import torch.nn.functional as F
    wn, sr = new["waveform"], int(new["sample_rate"])
    wo, sro = old_tail["waveform"], int(old_tail["sample_rate"])
    if sro != sr:
        wo = F.interpolate(wo.float().reshape(-1, 1, wo.shape[-1]), size=int(round(wo.shape[-1] * sr / sro)),
                           mode="linear", align_corners=False).reshape(*wo.shape[:-1], -1)
    if wo.shape[-2] != wn.shape[-2]:
        wo = wo.mean(-2, keepdim=True).expand(*wn.shape[:-1], wo.shape[-1]) if wn.shape[-2] > 1 else wo.mean(-2, keepdim=True)
    wo = wo.to(wn.device, wn.dtype)
    if wo.dim() < wn.dim():
        wo = wo.unsqueeze(0)
    c = min(int(round(cut_s * sr)), wn.shape[-1])
    b = wo[..., int(round(old_from_s * sr)):]
    k = min(int(fade_s * sr), c, b.shape[-1])
    a = wn[..., :c].clone()
    if k > 0:
        w = torch.linspace(0, 1, k, device=a.device, dtype=a.dtype)
        a[..., -k:] = a[..., -k:] * (1 - w) + b[..., :k] * w
        b = b[..., k:]
    return {"waveform": torch.cat([a, b.expand(*a.shape[:-1], b.shape[-1])], -1).contiguous(), "sample_rate": sr}


def opening_lowfreq_grade(body, guide_frame, frames=12, weight0=0.7, blur=64):
    """Ease the first frames' lighting/color toward the frame right before the cut.
    Only the blurred (low-frequency) difference is added, so edges/poses are never
    copied -> no ghosting (idea from MiniMaxH3 Director's export grade)."""
    n = min(int(frames), int(body.shape[0]))
    if n < 1 or weight0 <= 0:
        return body
    g = _box_blur(guide_frame[:1].float(), blur)
    out = body.clone()
    for i in range(n):
        w = weight0 * (1.0 - i / n)
        f = out[i:i + 1].float()
        out[i:i + 1] = (f + w * (g - _box_blur(f, blur))).clamp(0, 1).to(out.dtype)
    return out


class H3BatchSaveShot(io.ComfyNode):
    @classmethod
    def define_schema(cls):
        return io.Schema(
            node_id="H3BatchSaveShot",
            display_name="H3 保存镜头（接缝+对色+拼接+清理）",
            category="H3 连续镜头批量",
            description="v2：用重叠段整体对色 → 自动找画面最吻合的接缝点 → 低频过渡开头光色 → 保存 → 去重拼接完整版 → 清理显存内存。",
            is_output_node=True,
            inputs=[
                io.Image.Input("images"),
                io.Audio.Input("audio", optional=True),
                io.String.Input("project", force_input=True),
                io.Int.Input("shot_index", force_input=True),
                io.Int.Input("crop_frames", force_input=True),
                io.Image.Input("color_ref", optional=True),
                TailLock_T.Input("tail_lock", optional=True, tooltip="接自动衔接节点的“结尾锁定”。修复模式下用来把结尾接回旧视频"),
                io.String.Input("prompt", optional=True, force_input=True),
                io.Boolean.Input("color_match", default=True, label_on="对齐上一镜颜色", label_off="不对色"),
                io.Float.Input("color_strength", default=1.0, min=0.0, max=1.0, step=0.05),
                io.Combo.Input("color_method", options=COLOR_METHODS, default=COLOR_METHODS[0],
                               tooltip="重叠段整体对色：拿两镜“同一时刻”的画面比颜色，最准。其它三项是 v1 的“只对最后一帧”做法。"),
                io.Boolean.Input("build_full_video", default=True, label_on="自动拼接完整版", label_off="不拼接"),
                io.Boolean.Input("free_memory", default=True, label_on="跑完清理显存内存", label_off="不清理"),
                io.Combo.Input("seam_mode", options=SEAM_MODES, default=SEAM_MODES[0],
                               tooltip="自动：在衔接段里找新旧画面最吻合的那一帧切换，减少跳动。完整版里会自动去掉重复部分。"),
                io.Int.Input("opening_grade_frames", default=12, min=0, max=48,
                             tooltip="接缝后前多少帧的光线颜色慢慢过渡（只动模糊后的低频，不会重影）。0 = 关闭"),
                io.Combo.Input("subtitle_mode", options=SUBTITLE_MODES, default=SUBTITLE_MODES[0],
                               tooltip="v4：字幕文字直接取提示词里 <d>…</d> 的台词，拼完整版时自动生成 完整版.srt；烧进画面会另存 完整版_字幕.mp4"),
            ],
            outputs=[io.String.Output("file", display_name="保存路径")],
        )

    @classmethod
    def execute(cls, images, project, shot_index, crop_frames, audio=None, color_ref=None, prompt=None,
                color_match=True, color_strength=1.0, color_method=COLOR_METHODS[0], build_full_video=True,
                free_memory=True, seam_mode=SEAM_MODES[0], opening_grade_frames=12, subtitle_mode=SUBTITLE_MODES[0],
                tail_lock=None):
        import json
        n_ctx = int(crop_frames or 0)
        images = images.float()
        H, W = int(images.shape[1]), int(images.shape[2])
        prev_ctx = None
        if color_ref is not None and n_ctx > 0:
            prev_ctx = _fit(color_ref, H, W)
        overlap_ok = prev_ctx is not None and prev_ctx.shape[0] == n_ctx and n_ctx < images.shape[0]

        # 1) 颜色
        if color_match and n_ctx > 0 and prev_ctx is not None and color_strength > 0:
            if color_method == COLOR_METHODS[0] and overlap_ok:
                try:
                    images = overlap_color_match(images, images[:n_ctx], prev_ctx, color_strength)
                except Exception as e:
                    print(f"[H3BatchShots] ⚠️ 重叠段对色失败，跳过：{e}")
            elif color_method != COLOR_METHODS[0]:
                ct = get_core_node("ColorTransfer")
                if ct is not None:
                    body = images[n_ctx:]
                    body = _node_output_first(ct.execute(
                        image_target=body, image_ref=prev_ctx[-1:], method=color_method,
                        source_stats={"source_stats": "target_frame", "target_index": 0}, strength=float(color_strength)))
                    images = torch.cat([images[:n_ctx], body.float()], 0)

        # 2) 接缝点
        cut = n_ctx
        seam_info = {}
        if n_ctx > 0 and overlap_ok and seam_mode == SEAM_MODES[0]:
            pg, pp = _proxy(images[:n_ctx]), _proxy(prev_ctx)
            mads = [float((pg[k] - pp[k]).abs().mean()) * 255 for k in range(n_ctx)]
            lo = max(1, n_ctx // 4)
            cut = min(range(lo, n_ctx), key=lambda k: (round(mads[k], 1), -k))
            seam_info = {"mad_at_cut": round(mads[cut], 2), "mad_at_end": round(mads[-1], 2)}
            print(f"[H3BatchShots] 衔接段新旧画面差异（每帧）：{[round(m, 1) for m in mads]}")
            print(f"[H3BatchShots] 选第 {cut} 帧做接缝（差异 {mads[cut]:.1f}，v1 固定位置的差异约 {mads[-1]:.1f}）")
        trim_prev = n_ctx - cut if n_ctx > 0 else 0

        if cut >= images.shape[0]:
            raise ValueError(f"衔接帧 {cut} ≥ 总帧数 {images.shape[0]}，没有新内容可保存。")
        images = images[cut:]
        if audio is not None and cut > 0:
            sr = int(audio["sample_rate"])
            c = int(round(cut / FPS * sr))
            audio = {"waveform": audio["waveform"][..., c:].contiguous(), "sample_rate": sr}

        # 3) 开头低频光色过渡
        if n_ctx > 0 and prev_ctx is not None and opening_grade_frames > 0:
            guide = prev_ctx[max(cut - 1, 0):max(cut, 1)]
            images = opening_lowfreq_grade(images, guide, frames=opening_grade_frames)

        # 3.5) v5.1 修复模式：结尾在锁定区里找新旧最吻合的一帧，从那里接回旧视频（画面+声音）
        tail_info = {}
        repair = bool(tail_lock and tail_lock.get("repair"))
        if tail_lock and tail_lock.get("frames") is not None:
            T = _fit(tail_lock["frames"], H, W)
            n_t, M = int(T.shape[0]), int(images.shape[0])
            if M > n_t + 2:
                g, gp = _proxy(images[M - n_t:]), _proxy(T)
                mads = [float((g[i] - gp[i]).abs().mean()) * 255 for i in range(n_t)]
                lo = 0 if n_t <= 5 else n_t // 4
                i0 = min(range(lo, n_t), key=lambda i: (round(mads[i], 1), i))
                splice = M - n_t + i0
                pre = images[:splice]
                if pre.shape[0] > 0:
                    pre = opening_lowfreq_grade(pre.flip(0), T[i0:i0 + 1], frames=opening_grade_frames or 12).flip(0)
                images = torch.cat([pre, T[i0:].to(images.dtype)], 0)
                if audio is not None and tail_lock.get("audio") is not None:
                    audio = _splice_audio(audio, tail_lock["audio"], splice / FPS, i0 / FPS)
                tail_info = {"tail_locked": True, "tail_frames": n_t, "tail_splice_at": int(i0),
                             "tail_mad": round(mads[i0], 2), "next_mtime_at_lock": tail_lock["next_mtime"]}
                print(f"[H3BatchShots] 修复模式：结尾锁定区新旧差异（每帧）{[round(m, 1) for m in mads]}，"
                      f"从锁定区第 {i0} 帧起接回旧视频（差异 {mads[i0]:.1f}）")
            else:
                print("[H3BatchShots] ⚠️ 修复模式：这段太短，没做结尾拼接")

        # 4) 保存
        full_dir, sub = project_dir(project)
        fname = f"shot_{shot_index:03d}.mp4"
        path = os.path.join(full_dir, fname)
        video = InputImpl.VideoFromComponents(
            Types.VideoComponents(images=images, audio=audio, frame_rate=Fraction(FPS)))
        tmp = path + ".tmp.mp4"
        video.save_to(tmp, format=Types.VideoContainer.MP4, codec=Types.VideoCodec.H264)
        # v4：这一镜以前跑过，先把旧文件挪进“旧版”文件夹，方便对比和反悔
        if os.path.exists(path):
            old_dir = os.path.join(full_dir, "旧版")
            os.makedirs(old_dir, exist_ok=True)
            stamp = time.strftime("%m%d_%H%M%S")
            for suffix in (".mp4", ".json", "_提示词.txt"):
                src = os.path.join(full_dir, f"shot_{shot_index:03d}{suffix}")
                if os.path.exists(src):
                    try:
                        os.replace(src, os.path.join(old_dir, f"shot_{shot_index:03d}_{stamp}{suffix}"))
                    except OSError as e:
                        print(f"[H3BatchShots] ⚠️ 旧文件没能挪走（{e}），直接覆盖")
            print(f"[H3BatchShots] 镜头{shot_index} 的旧版本已挪到：{old_dir}")
        os.replace(tmp, path)
        meta = {"frames": int(images.shape[0]), "trim_prev_tail": int(trim_prev), "context_frames": n_ctx,
                "cut_at": int(cut), **seam_info, "subtitles": dialog_lines(prompt), **tail_info}
        with open(os.path.join(full_dir, f"shot_{shot_index:03d}.json"), "w", encoding="utf-8") as f:
            json.dump(meta, f, ensure_ascii=False, indent=1)
        if prompt:
            with open(os.path.join(full_dir, f"shot_{shot_index:03d}_提示词.txt"), "w", encoding="utf-8") as f:
                f.write(prompt)
        print(f"[H3BatchShots] 镜头{shot_index} 已保存：{path}（{images.shape[0]} 帧，完整版里会去掉上一镜末尾 {trim_prev} 帧重复）")

        if build_full_video:
            try:
                out_name = cls._repair_name(full_dir, int(shot_index)) if repair else "完整版.mp4"
                out_path = cls._concat(full_dir, out_name)
                if out_path and subtitle_mode != SUBTITLE_MODES[2]:
                    cls._subtitles(full_dir, out_path, burn=(subtitle_mode == SUBTITLE_MODES[0]))
            except Exception as e:
                print(f"[H3BatchShots] ⚠️ 拼接完整版或字幕失败（不影响单镜文件）：{e}")

        result_ui = ui.PreviewVideo([ui.SavedResult(fname, sub, io.FolderType.output)])
        if free_memory:
            del images, audio, video, prev_ctx
            free_all_memory(f"镜头{shot_index}")
        return io.NodeOutput(path, ui=result_ui)

    @staticmethod
    def _chain(full_dir):
        files = sorted(f for f in os.listdir(full_dir) if re.fullmatch(r"shot_\d{3}\.mp4", f))
        chain = []
        prev_mtime = None
        prev_meta = {}
        for i, f in enumerate(files, start=1):
            if f != f"shot_{i:03d}.mp4":
                break
            path = os.path.join(full_dir, f)
            mtime = os.path.getmtime(path)
            meta = H3BatchSaveShot._meta(full_dir, f)
            # v3.1：衔接镜头比上一镜还旧 = 上一镜重跑过、这一镜还没重跑，内容对不上，先不拼
            locked_ok = bool(prev_meta.get("tail_locked")) and abs(mtime - float(prev_meta.get("next_mtime_at_lock", -1))) < 2
            if prev_mtime is not None and int(meta.get("context_frames", 0) or 0) > 0 and mtime < prev_mtime and not locked_ok:
                print(f"[H3BatchShots] 完整版先拼到第 {i - 1} 镜：{f} 是旧的（上一镜重跑过，它还没重跑）")
                break
            chain.append(f)
            prev_mtime = mtime
            prev_meta = meta
        return chain

    @staticmethod
    def _publish(tmp, out):
        """v3.1：完整版.mp4 正被播放器打开时 Windows 不让覆盖，改存成 完整版_新.mp4。"""
        try:
            os.replace(tmp, out)
            return out
        except PermissionError:
            alt = out[:-4] + "_新.mp4"
            try:
                os.replace(tmp, alt)
            except PermissionError:
                raise RuntimeError(f"{os.path.basename(out)} 和它的 _新 版本都被占用，请关掉播放器")
            print(f"[H3BatchShots] ⚠️ {os.path.basename(out)} 正被播放器占用，这次存成：{alt}（关掉播放器后下一镜会正常覆盖）")
            return alt

    @staticmethod
    def _meta(full_dir, name):
        import json
        p = os.path.join(full_dir, name.replace(".mp4", ".json"))
        if os.path.isfile(p):
            try:
                with open(p, encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
        return {}

    @classmethod
    def _repair_name(cls, full_dir: str, shot_index: int) -> str:
        """v5.2：记下这个版本里修过哪些段，完整版另存为 完整版_修复第4、6段.mp4；重名就加 _2、_3。"""
        import json
        rec = os.path.join(full_dir, "修复记录.json")
        done = []
        try:
            with open(rec, encoding="utf-8") as f:
                done = list(json.load(f).get("repaired", []))
        except Exception:
            pass
        done = sorted(set(int(x) for x in done) | {shot_index})
        with open(rec, "w", encoding="utf-8") as f:
            json.dump({"repaired": done, "说明": "修复模式下修过的段；完整版另存，不覆盖原来的 完整版.mp4"}, f, ensure_ascii=False, indent=1)
        base = "完整版_修复第" + "、".join(str(x) for x in done) + "段"
        name, k = base + ".mp4", 2
        while os.path.exists(os.path.join(full_dir, name)):
            name = f"{base}_{k}.mp4"
            k += 1
        return name

    @classmethod
    def _concat(cls, full_dir: str, out_name: str = "完整版.mp4"):
        import imageio_ffmpeg
        chain = cls._chain(full_dir)
        if not chain:
            return
        exe = imageio_ffmpeg.get_ffmpeg_exe()
        out = os.path.join(full_dir, out_name)
        tmp = os.path.join(full_dir, "_完整版_tmp.mp4")
        metas = [cls._meta(full_dir, f) for f in chain]
        trims = [int(metas[i + 1].get("trim_prev_tail", 0)) if i + 1 < len(chain) else 0 for i in range(len(chain))]
        if any(trims) and all("frames" in m for m in metas):
            args = [exe, "-y", "-loglevel", "error"]
            for f in chain:
                args += ["-i", os.path.join(full_dir, f)]
            parts, labels = [], []
            for i, (m, t) in enumerate(zip(metas, trims)):
                end_f = max(1, int(m["frames"]) - t)
                end_s = end_f / FPS
                parts.append(f"[{i}:v]trim=end_frame={end_f},setpts=PTS-STARTPTS,fps={FPS},format=yuv420p,setsar=1[v{i}]")
                fo = max(0.0, end_s - 0.012)
                parts.append(f"[{i}:a]atrim=end={end_s:.4f},asetpts=PTS-STARTPTS,aresample=48000,"
                             f"afade=t=in:d=0.012,afade=t=out:st={fo:.4f}:d=0.012[a{i}]")
                labels.append(f"[v{i}][a{i}]")
            fc = ";".join(parts) + ";" + "".join(labels) + f"concat=n={len(chain)}:v=1:a=1[v][a]"
            args += ["-filter_complex", fc, "-map", "[v]", "-map", "[a]", "-c:v", "libx264", "-crf", "17",
                     "-preset", "medium", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k", tmp]
            r = subprocess.run(args, capture_output=True, text=True, timeout=3600)
            if r.returncode == 0:
                out = cls._publish(tmp, out)
                print(f"[H3BatchShots] 完整版已更新（去重拼接）：{out}（{len(chain)} 镜，去掉重复 {trims} 帧）")
                return out
            print(f"[H3BatchShots] ⚠️ 去重拼接失败，改用普通拼接：{r.stderr[-300:]}")
        lst = os.path.join(full_dir, "_concat_list.txt")
        with open(lst, "w", encoding="utf-8") as fh:
            for f in chain:
                fh.write("file '" + os.path.join(full_dir, f).replace("\\", "/").replace("'", "'\\''") + "'\n")
        base = [exe, "-y", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", lst]
        r = subprocess.run(base + ["-c", "copy", tmp], capture_output=True, text=True, timeout=600)
        if r.returncode != 0:
            r = subprocess.run(base + ["-c:v", "libx264", "-crf", "18", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k", tmp],
                               capture_output=True, text=True, timeout=1800)
        if r.returncode != 0:
            raise RuntimeError(r.stderr[-500:])
        out = cls._publish(tmp, out)
        print(f"[H3BatchShots] 完整版已更新：{out}（{len(chain)} 镜）")
        return out

    @classmethod
    def _subtitles(cls, full_dir: str, video_path: str, burn: bool):
        """v4：按每镜实际时长排字幕。每镜的台词在这一镜的时间段里按字数分配显示时间。"""
        import imageio_ffmpeg
        chain = cls._chain(full_dir)
        metas = [cls._meta(full_dir, f) for f in chain]
        trims = [int(metas[i + 1].get("trim_prev_tail", 0)) if i + 1 < len(chain) else 0 for i in range(len(chain))]
        cues, t = [], 0.0
        for f, m, tr in zip(chain, metas, trims):
            dur = max(0.0, (int(m.get("frames", 0)) - tr) / FPS)
            lines = m.get("subtitles", [])
            if lines and dur > 0.6:
                groups = []
                try:
                    groups = utterances(speech_spans(load_mono_16k(os.path.join(full_dir, f))), len(lines))
                except Exception as e:
                    print(f"[H3BatchShots] ⚠️ {f} 人声检测失败，按整段时长排字幕：{e}")
                for k, line in enumerate(lines):
                    pieces = split_caption(line)
                    if not pieces:
                        continue
                    if len(groups) == len(lines):
                        placed = place_pieces(pieces, groups[k])
                        how = "按人声"
                    else:
                        seg = (dur - 0.25) / len(lines)
                        placed = place_pieces(pieces, [(0.15 + k * seg, 0.15 + (k + 1) * seg)])
                        how = "没检测到人声，按时长平均"
                    for a, b, x in placed:
                        a = max(0.0, a - 0.08)
                        b = min(dur - 0.04, b + 0.25)
                        cues.append([t + a, t + b, x])
                    print(f"[H3BatchShots] 字幕 {f}：{how}，{placed[0][0]:.2f}s–{placed[-1][1]:.2f}s，{len(placed)} 条")
            t += dur
        cues.sort(key=lambda c: c[0])
        for i in range(len(cues) - 1):
            cues[i][1] = min(cues[i][1], cues[i + 1][0] - 0.02)
        if not cues:
            print("[H3BatchShots] 提示词里没有 <d>…</d> 台词，不生成字幕")
            return
        srt = "\n".join(f"{i}\n{srt_time(a)} --> {srt_time(b)}\n{x}\n" for i, (a, b, x) in enumerate(cues, start=1))
        base = os.path.splitext(os.path.basename(video_path))[0]
        srt_path = os.path.join(full_dir, base + ".srt")
        with open(srt_path, "w", encoding="utf-8-sig") as f:
            f.write(srt)
        print(f"[H3BatchShots] 字幕已生成：{srt_path}（{len(cues)} 条）")
        if not burn:
            return
        with open(os.path.join(full_dir, "_subs.srt"), "w", encoding="utf-8") as f:
            f.write(srt)
        exe = imageio_ffmpeg.get_ffmpeg_exe()
        style = ("FontName=Microsoft YaHei,FontSize=22,Bold=1,Spacing=0.5,PrimaryColour=&H00FFFFFF,"
                 "OutlineColour=&H00202020,BackColour=&H96000000,BorderStyle=1,Outline=1.4,Shadow=1.2,MarginV=20")
        tmp = os.path.join(full_dir, "_字幕_tmp.mp4")
        args = [exe, "-y", "-loglevel", "error", "-i", os.path.basename(video_path),
                "-vf", f"subtitles=_subs.srt:charenc=UTF-8:force_style='{style}'",
                "-c:v", "libx264", "-crf", "17", "-preset", "medium", "-pix_fmt", "yuv420p", "-c:a", "copy", tmp]
        r = subprocess.run(args, capture_output=True, text=True, timeout=3600, cwd=full_dir)
        if r.returncode != 0:
            print(f"[H3BatchShots] ⚠️ 字幕烧进画面失败，只保留 srt 文件（可在剪映/播放器里加载）：{r.stderr[-300:]}")
            return
        out = os.path.join(full_dir, base + "_字幕.mp4")
        try:
            os.replace(tmp, out)
        except PermissionError:
            out = os.path.join(full_dir, base + "_字幕_新.mp4")
            os.replace(tmp, out)
            print(f"[H3BatchShots] ⚠️ {base}_字幕.mp4 正被播放器占用，这次另存了一份")
        print(f"[H3BatchShots] 带字幕的完整版：{out}")


# ----------------------------------------------------------------- 4. 参考库（v5）
H3RefLibrary_T = io.Custom("H3_REF_LIBRARY")
REF_TAG_RE = re.compile(r"<(Picture|Video|Audio|VideoAudio) (\d+)>")
REF_TAG_LOOSE_RE = re.compile(r"<\s*(picture|video|audio|videoaudio)\s*(\d+)\s*>", re.I)
H3_LIMITS = {"Picture": 9, "Video": 3, "VideoAudio": 3, "Audio": 3}


def _autogrow_items(d, prefix):
    """把 Autogrow 输入按编号排好：{'img_0': x, 'img_1': y} -> [(0, x), (1, y)]，空口跳过但编号保留。"""
    out = []
    for k, v in (d or {}).items():
        m = re.search(r"(\d+)$", k)
        if v is not None and m:
            out.append((int(m.group(1)), v))
    return sorted(out)


class H3RefLibraryNode(io.ComfyNode):
    @classmethod
    def define_schema(cls):
        return io.Schema(
            node_id="H3RefLibrary",
            display_name="H3 参考库（图片/视频/音频，数量不限）",
            category="H3 连续镜头批量",
            description=("把全片所有参考素材放在这里，按连线顺序统一编号："
                         "图片 = <Picture 1>、<Picture 2>…；视频 = <Video 1>…；视频原声 = <VideoAudio 1>…（和同号视频配对）；"
                         "独立音频（比如角色嗓音）= <Audio 1>…。每段生成时只送这段提示词里写到的参考。"
                         "接不下时，把另一个参考库接到“接上一个参考库”，编号接着往后排。"),
            inputs=[
                io.Autogrow.Input("images", optional=True, template=io.Autogrow.TemplatePrefix(
                    input=io.Image.Input("image", tooltip="参考图：人物/服装/场景/画风都行"), prefix="image_", min=0, max=30)),
                io.Autogrow.Input("videos", optional=True, template=io.Autogrow.TemplatePrefix(
                    input=io.Image.Input("video", tooltip="参考视频画面（24fps，2-15 秒）"), prefix="video_", min=0, max=10)),
                io.Autogrow.Input("video_audios", optional=True, template=io.Autogrow.TemplatePrefix(
                    input=io.Audio.Input("video_audio", tooltip="同号参考视频的原声，提示词里写 <VideoAudio N>"), prefix="video_audio_", min=0, max=10)),
                io.Autogrow.Input("audios", optional=True, template=io.Autogrow.TemplatePrefix(
                    input=io.Audio.Input("audio", tooltip="独立参考音频，比如角色嗓音"), prefix="audio_", min=0, max=10)),
                H3RefLibrary_T.Input("previous", optional=True, tooltip="接上一个参考库（素材多时串联用），它的编号排在前面"),
            ],
            outputs=[H3RefLibrary_T.Output(display_name="参考库")],
        )

    @classmethod
    def execute(cls, images=None, videos=None, video_audios=None, audios=None, previous=None):
        lib = _copy_lib(previous)
        base_v = len(lib["Video"])
        for _, x in _autogrow_items(images, "图片_"):
            lib["Picture"].append(x)
            lib["_names"]["Picture"].append("")
        vids = _autogrow_items(videos, "视频_")
        vaud = dict(_autogrow_items(video_audios, "视频原声_"))
        for idx, x in vids:
            lib["Video"].append(x)
            lib["_names"]["Video"].append("")
            lib["VideoAudio"].append(vaud.get(idx))  # 和视频一一对应，没有原声就是 None
        for _, x in _autogrow_items(audios, "音频_"):
            lib["Audio"].append(x)
            lib["_names"]["Audio"].append("")
        summary = (f"参考库：图片 {len(lib['Picture'])} 张，视频 {len(lib['Video'])} 段"
                   f"（其中带原声 {sum(1 for a in lib['VideoAudio'] if a is not None)} 段），独立音频 {len(lib['Audio'])} 段")
        print("[H3BatchShots] " + summary)
        return io.NodeOutput(lib, ui={"text": [summary]})

NO_FILE = "（不选文件）"


def _input_files(kind: str) -> list[str]:
    d = folder_paths.get_input_directory()
    try:
        files = [f for f in os.listdir(d) if os.path.isfile(os.path.join(d, f))]
    except Exception:
        files = []
    try:
        files = folder_paths.filter_files_content_types(files, [kind])
    except Exception:
        ext = {"image": (".png", ".jpg", ".jpeg", ".webp", ".bmp"), "video": (".mp4", ".mov", ".webm", ".mkv", ".avi"),
               "audio": (".wav", ".mp3", ".flac", ".ogg", ".m4a", ".aac")}[kind]
        files = [f for f in files if f.lower().endswith(ext)]
    return [NO_FILE] + sorted(files)


def _empty_lib():
    return {"Picture": [], "Video": [], "VideoAudio": [], "Audio": [], "_names": {"Picture": [], "Video": [], "Audio": []}}


def _copy_lib(prev):
    lib = _empty_lib()
    if prev:
        for k in ("Picture", "Video", "VideoAudio", "Audio"):
            lib[k] = list(prev.get(k, []))
        for k in ("Picture", "Video", "Audio"):
            lib["_names"][k] = list(prev.get("_names", {}).get(k, [""] * len(lib[k])))
    return lib


class _RefItemBase(io.ComfyNode):
    KIND = "Picture"
    LABEL = "参考图"

    @classmethod
    def _finish(cls, lib, value, note, extra_audio=None, on=True):
        tag = {"Picture": "Picture", "Video": "Video", "Audio": "Audio"}[cls.KIND]
        lib[cls.KIND].append(value if on else None)
        lib["_names"][cls.KIND].append(note or "")
        if cls.KIND == "Video":
            lib["VideoAudio"].append(extra_audio if on else None)
        n = len(lib[cls.KIND])
        state = "开" if (on and value is not None) else "关"
        msg = f"<{tag} {n}>：{note or cls.LABEL}（{state}）"
        if cls.KIND == "Video" and on and value is not None:
            msg += f"，原声 <VideoAudio {n}>：{'有' if extra_audio is not None else '没有'}"
        print("[H3BatchShots] 参考 " + msg)
        return io.NodeOutput(lib, ui={"text": [msg]})


class H3RefImage(_RefItemBase):
    KIND, LABEL = "Picture", "参考图"

    @classmethod
    def define_schema(cls):
        return io.Schema(
            node_id="H3RefImage", display_name="H3 参考图（带开关）", category="H3 连续镜头批量",
            description="一张参考图。串在参考链里，第几个参考图就是 <Picture 几>。连了“图像”口就用连线的图，否则用选的文件。开关关掉时编号保留。",
            inputs=[
                H3RefLibrary_T.Input("previous", optional=True, tooltip="接上一个参考节点"),
                io.Image.Input("image", optional=True, tooltip="可选：直接连图像（比如首帧图），连了就不用选文件"),
                io.Boolean.Input("enabled", default=True, label_on="用这个参考", label_off="不用（编号保留）"),
                io.Combo.Input("file", options=_input_files("image"), upload=io.UploadType.image),
                io.String.Input("note", default="", tooltip="备注，比如“女主正面”，只在日志里显示"),
            ],
            outputs=[H3RefLibrary_T.Output(display_name="参考链")],
        )

    @classmethod
    def execute(cls, enabled=True, file=NO_FILE, note="", previous=None, image=None):
        lib = _copy_lib(previous)
        val = None
        if enabled:
            if image is not None:
                val = image[:1]
            elif file and file != NO_FILE:
                val = nodes_mod().LoadImage().load_image(file)[0][:1]
            else:
                raise ValueError(f"参考图“{note or '未命名'}”开着，但既没连图像也没选文件")
        return cls._finish(lib, val, note, on=enabled)


class H3RefAudio(_RefItemBase):
    KIND, LABEL = "Audio", "参考音频"

    @classmethod
    def define_schema(cls):
        return io.Schema(
            node_id="H3RefAudio", display_name="H3 参考音频（带开关）", category="H3 连续镜头批量",
            description="一段独立参考音频（比如角色嗓音）。第几个参考音频就是 <Audio 几>。开关关掉时编号保留。",
            inputs=[
                H3RefLibrary_T.Input("previous", optional=True),
                io.Audio.Input("audio", optional=True, tooltip="可选：直接连音频"),
                io.Boolean.Input("enabled", default=False, label_on="用这个参考", label_off="不用（编号保留）"),
                io.Combo.Input("file", options=_input_files("audio"), upload=io.UploadType.audio),
                io.String.Input("note", default="", tooltip="备注，比如“女主嗓音”"),
            ],
            outputs=[H3RefLibrary_T.Output(display_name="参考链")],
        )

    @classmethod
    def execute(cls, enabled=False, file=NO_FILE, note="", previous=None, audio=None):
        lib = _copy_lib(previous)
        val = None
        if enabled:
            if audio is not None:
                val = audio
            elif file and file != NO_FILE:
                val = _node_output_first(get_core_node("LoadAudio").execute(audio=file))
            else:
                raise ValueError(f"参考音频“{note or '未命名'}”开着，但既没连音频也没选文件")
        return cls._finish(lib, val, note, on=enabled)


class H3RefVideo(_RefItemBase):
    KIND, LABEL = "Video", "参考视频"

    @classmethod
    def define_schema(cls):
        return io.Schema(
            node_id="H3RefVideo", display_name="H3 参考视频（带开关）", category="H3 连续镜头批量",
            description="一段参考视频（24fps、2-15 秒最好）。第几个参考视频就是 <Video 几>，它的原声是 <VideoAudio 几>。开关关掉时编号保留。",
            inputs=[
                H3RefLibrary_T.Input("previous", optional=True),
                io.Video.Input("video", optional=True, tooltip="可选：直接连视频"),
                io.Boolean.Input("enabled", default=False, label_on="用这个参考", label_off="不用（编号保留）"),
                io.Boolean.Input("keep_audio", default=True, label_on="带原声", label_off="不要原声"),
                io.Combo.Input("file", options=_input_files("video"), upload=io.UploadType.video),
                io.String.Input("note", default="", tooltip="备注，比如“舞蹈动作参考”"),
            ],
            outputs=[H3RefLibrary_T.Output(display_name="参考链")],
        )

    @classmethod
    def execute(cls, enabled=False, keep_audio=True, file=NO_FILE, note="", previous=None, video=None):
        lib = _copy_lib(previous)
        frames = aud = None
        if enabled:
            if video is None:
                if not file or file == NO_FILE:
                    raise ValueError(f"参考视频“{note or '未命名'}”开着，但既没连视频也没选文件")
                video = InputImpl.VideoFromFile(folder_paths.get_annotated_filepath(file))
            comp = video.get_components()
            frames = comp.images
            if keep_audio and comp.audio is not None:
                aud = comp.audio
        return cls._finish(lib, frames, note, extra_audio=aud, on=enabled)


def nodes_mod():
    import nodes
    return nodes



class H3BatchRefToVideo(io.ComfyNode):
    @classmethod
    def define_schema(cls):
        return io.Schema(
            node_id="H3BatchRefToVideo",
            display_name="H3 按段参考生成（自动挑参考）",
            category="H3 连续镜头批量",
            description=("代替官方 MiniMax H3 Reference to Video：读这段提示词里写了哪些 <Picture N>/<Video N>/<VideoAudio N>/<Audio N>，"
                         "只把这些参考送进模型，并自动改成从 1 开始的编号。提示词里一律写全片统一编号。"),
            inputs=[
                io.Clip.Input("clip"),
                io.Vae.Input("vae", optional=True),
                io.Vae.Input("audio_vae", optional=True),
                io.String.Input("prompt", multiline=True, force_input=True),
                io.Int.Input("width", force_input=True),
                io.Int.Input("height", force_input=True),
                io.Int.Input("length", force_input=True),
                H3RefLibrary_T.Input("library", optional=True, tooltip="接 H3 参考链/参考库（可选）。下面的参考接口连了任何一个，就用接口，不用这个"),
                io.Autogrow.Input("ref_images", optional=True, template=io.Autogrow.TemplatePrefix(
                    input=io.Image.Input("ref_image", tooltip="第几个接口就是 <Picture 几>（空着或被关掉的接口编号照样保留）"),
                    prefix="ref_image_", min=0, max=20)),
                io.Autogrow.Input("ref_videos", optional=True, template=io.Autogrow.TemplatePrefix(
                    input=io.Image.Input("ref_video", tooltip="第几个接口就是 <Video 几>（24fps）"), prefix="ref_video_", min=0, max=6)),
                io.Autogrow.Input("ref_video_audios", optional=True, template=io.Autogrow.TemplatePrefix(
                    input=io.Audio.Input("ref_video_audio", tooltip="同号参考视频的原声，提示词写 <VideoAudio 几>"), prefix="ref_video_audio_", min=0, max=6)),
                io.Autogrow.Input("ref_audios", optional=True, template=io.Autogrow.TemplatePrefix(
                    input=io.Audio.Input("ref_audio", tooltip="第几个接口就是 <Audio 几>，比如角色嗓音"), prefix="ref_audio_", min=0, max=6)),
                io.Combo.Input("ref_image_size", options=["match", "max"], default="match",
                               tooltip="match：参考图缩到和生成画面差不多大（快）；max：按 2048 短边送（身份更准，但慢很多）"),
                io.Combo.Input("select_mode", options=["只送提示词里写到的（推荐）", "全部都送"], default="只送提示词里写到的（推荐）",
                               tooltip="全部都送 = 老做法，参考库里的东西每段都送进去"),
            ],
            outputs=[io.Conditioning.Output(display_name="positive"), io.Latent.Output()],
        )

    @classmethod
    def execute(cls, clip, prompt, width, height, length, vae=None, audio_vae=None, library=None,
                ref_image_size="match", select_mode="只送提示词里写到的（推荐）",
                ref_images=None, ref_videos=None, ref_video_audios=None, ref_audios=None):
        core = get_core_node("MiniMaxH3ReferenceToVideo")
        if core is None:
            raise RuntimeError("找不到官方节点 MiniMaxH3ReferenceToVideo，请更新 ComfyUI")
        socks = [d for d in (ref_images, ref_videos, ref_video_audios, ref_audios) if d and any(v is not None for v in d.values())]
        if socks:
            # v5.3：按接口位置编号，空着/关掉的接口占位（None），后面的编号不变
            def slots(d):
                items = _autogrow_items(d, "")
                out = [None] * (max([i for i, _ in items], default=-1) + 1)
                for i, v in items:
                    out[i] = v
                return out
            lib = _empty_lib()
            lib["Picture"] = slots(ref_images)
            lib["Video"] = slots(ref_videos)
            va = slots(ref_video_audios)
            lib["VideoAudio"] = (va + [None] * len(lib["Video"]))[:max(len(lib["Video"]), len(va))]
            lib["Audio"] = slots(ref_audios)
            if library:
                print("[H3BatchShots] 参考接口已连接，忽略“参考链/参考库”输入")
        else:
            lib = library or _empty_lib()

        # 1) 疑似写错的标签（大小写、少空格等）提醒一下
        for m in REF_TAG_LOOSE_RE.finditer(prompt or ""):
            if not REF_TAG_RE.fullmatch(m.group(0)):
                print(f"[H3BatchShots] ⚠️ 提示词里的 {m.group(0)} 写法不标准，认不出来；应写成 <Picture 1> / <Video 1> / <VideoAudio 1> / <Audio 1>")

        # 2) 这段用到哪些
        if select_mode.startswith("全部"):
            used = {"Picture": [i + 1 for i, x in enumerate(lib["Picture"]) if x is not None],
                    "Video": [i + 1 for i, x in enumerate(lib["Video"]) if x is not None],
                    "VideoAudio": [i + 1 for i, a in enumerate(lib["VideoAudio"]) if a is not None],
                    "Audio": [i + 1 for i, x in enumerate(lib["Audio"]) if x is not None]}
        else:
            used = {k: set() for k in lib}
            for kind, n in REF_TAG_RE.findall(prompt or ""):
                used[kind].add(int(n))
            used["Video"] |= used["VideoAudio"]  # 用了原声就一定带上那段视频
            used = {k: sorted(v) for k, v in used.items()}

        # 3) 检查：编号存在、单段上限
        errs = []
        for kind, nums in used.items():
            have = len(lib[kind])
            for n in nums:
                if n < 1 or n > have:
                    errs.append(f"<{kind} {n}>（参考库里只有 {have} 个）")
                elif kind != "VideoAudio" and lib[kind][n - 1] is None:
                    errs.append(f"<{kind} {n}>（这个参考的开关是关的）")
                elif kind == "VideoAudio" and lib["VideoAudio"][n - 1] is None:
                    errs.append(f"<VideoAudio {n}>（第 {n} 个参考视频没有原声，或开关是关的）")
        if errs:
            raise ValueError("这段提示词用到的参考在参考库里找不到：" + "、".join(errs))
        for kind, lim in H3_LIMITS.items():
            if len(used[kind]) > lim:
                raise ValueError(f"这段用了 {len(used[kind])} 个 {kind}，H3 单段最多 {lim} 个。请拆段或减少这段的参考。")

        # 4) 重新编号：图片、视频按顺序 1..n；音频标签 = 先是选中视频的原声（按视频顺序），再是独立音频（和官方节点的排号规则一致）
        new = {("Picture", n): i + 1 for i, n in enumerate(used["Picture"])}
        new.update({("Video", n): i + 1 for i, n in enumerate(used["Video"])})
        j = 0
        for n in used["Video"]:
            if n in used["VideoAudio"]:
                j += 1
                new[("VideoAudio", n)] = j
        for n in used["Audio"]:
            j += 1
            new[("Audio", n)] = j

        def sub(m):
            kind, n = m.group(1), int(m.group(2))
            k = new.get((kind, n))
            if k is None:
                return m.group(0)
            return f"<Audio {k}>" if kind in ("Audio", "VideoAudio") else f"<{kind} {k}>"
        seg_prompt = REF_TAG_RE.sub(sub, prompt or "")

        ref_images = {f"ref_image_{i}": lib["Picture"][n - 1] for i, n in enumerate(used["Picture"])} or None
        ref_videos, ref_video_audios = {}, {}
        for i, n in enumerate(used["Video"]):
            ref_videos[f"ref_video_{i}"] = lib["Video"][n - 1]
            if n in used["VideoAudio"]:
                ref_video_audios[f"ref_video_audio_{i}"] = lib["VideoAudio"][n - 1]
        ref_audios = {f"ref_audio_{i}": lib["Audio"][n - 1] for i, n in enumerate(used["Audio"])} or None

        def show(kind, label):
            return ", ".join(f"{label}{n}→{new[(kind, n)]}" for n in used[kind]) or "无"
        print(f"[H3BatchShots] 本段参考：图片[{show('Picture', '')}]  视频[{show('Video', '')}]  "
              f"视频原声[{show('VideoAudio', '')}]  音频[{show('Audio', '')}]（左边是全片编号，右边是本段实际编号）")

        out = core.execute(clip=clip, prompt=seg_prompt, width=int(width), height=int(height), length=int(length),
                           ref_image_size=ref_image_size, vae=vae, audio_vae=audio_vae,
                           ref_images=ref_images, ref_videos=ref_videos or None,
                           ref_video_audios=ref_video_audios or None, ref_audios=ref_audios)
        args = getattr(out, "args", None) or out
        return io.NodeOutput(args[0], args[1])


class H3BatchShotsExtension(ComfyExtension):
    async def get_node_list(self):
        from .director_concat import H3DirectorConcat
        return [H3BatchShotList, H3BatchAutoGuide, H3BatchSaveShot, H3RefLibraryNode, H3BatchRefToVideo,
                H3RefImage, H3RefVideo, H3RefAudio, H3DirectorConcat]


async def comfy_entrypoint() -> H3BatchShotsExtension:
    return H3BatchShotsExtension()
