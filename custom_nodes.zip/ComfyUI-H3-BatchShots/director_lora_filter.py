"""v5.9d：导演台「分组 LoRA」只看指定文件夹里的 LoRA（默认只看文件夹名含 minimax 的）。

原因：导演台点「+ LoRA」时会把 models/loras 下所有 LoRA 都读一遍（文件头、元数据、预览图），
LoRA 多（几千个）时整个 ComfyUI 卡住。这里另开一个只扫指定文件夹的接口，前端补丁把导演台的请求转过来。
不改导演台插件文件。要看哪些文件夹写在「导演台LoRA只看这些文件夹.txt」里，一行一个关键词（文件夹名包含它就算），
文件清空（或只留 # 注释）= 不过滤，恢复导演台原样。
"""

from __future__ import annotations

import asyncio
import os

import folder_paths

CFG = os.path.join(os.path.dirname(os.path.abspath(__file__)), "导演台LoRA只看这些文件夹.txt")
DEFAULT_CFG = """# 导演台「分组 LoRA」只显示这些文件夹里的 LoRA（文件夹名包含下面任一关键词就算，不分大小写）
# 一行一个；清空所有关键词 = 显示全部 LoRA（恢复导演台原样）
minimax
"""


def keywords() -> list[str]:
    if not os.path.isfile(CFG):
        try:
            with open(CFG, "w", encoding="utf-8") as f:
                f.write(DEFAULT_CFG)
        except OSError:
            return ["minimax"]
    try:
        with open(CFG, encoding="utf-8-sig") as f:
            lines = f.read().splitlines()
    except OSError:
        return ["minimax"]
    return [x.strip().lower() for x in lines if x.strip() and not x.strip().startswith("#")]


def allowed(name: str, kws: list[str]) -> bool:
    if not kws:
        return True
    folders = str(name).replace("\\", "/").split("/")[:-1]
    return any(k in p.lower() for p in folders for k in kws)


def _catalog(kws):
    from .director_concat import _director_module

    lp = _director_module("director.lora_previews")
    out = {}
    for name in folder_paths.get_filename_list("loras"):
        if not allowed(name, kws):
            continue
        full = folder_paths.get_full_path("loras", name)
        if not full or not os.path.isfile(full):
            continue
        try:
            out[name] = lp._lora_info(name, full) if lp is not None else {"preview": None, "triggers": [], "tags": []}
        except Exception:  # noqa: BLE001
            continue
    return out


def register_routes():
    try:
        from aiohttp import web
        from server import PromptServer

        routes = PromptServer.instance.routes

        @routes.get("/h3bs/lora_filter")
        async def _filter(request):
            return web.json_response({"keywords": keywords()})

        @routes.get("/h3bs/lora_previews")
        async def _previews(request):
            try:
                cat = await asyncio.to_thread(_catalog, keywords())   # 放到后台线程，不卡界面
                previews = {n: i["preview"] for n, i in cat.items() if i.get("preview")}
                return web.json_response({"previews": previews, "catalog": cat})
            except Exception as e:  # noqa: BLE001
                return web.json_response({"previews": {}, "catalog": {}, "error": str(e)}, status=500)
    except Exception as e:  # noqa: BLE001
        print(f"[H3BatchShots] ⚠️ 导演台 LoRA 过滤接口没注册上：{e}")
