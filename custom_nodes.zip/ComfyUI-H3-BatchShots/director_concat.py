"""v5.9c（v5.9b + 原声模式的声音不再丢、rv2v/v2v 全局模式的参考图提醒不再误报、全局提示词里的 <os t=…> 字幕按整条视频时间出）：
v5.9b（v5.8c + 有拼接节点时让导演台每段都写缓存，单段也能拼；缓存里没有的段再退到分段导出的 mp4）：
v5.8c（v5.8b + 缺段不再报错：只拼缓存里已有的段，试跑两段也能出带字幕的小样）：
v5.8b（回到 v5.7，只加一个「运行前清空旧缓存」开关）：
v5.6（v5.5 + 多条字幕：<os>…</os> 内心/旁白/其他角色字幕，字幕样式表可调颜色和位置）：
v5.5（v5.4 + 说明.txt 增加“参考图/参考音频换过但这段没重跑”的提醒）：H3 导演台分段拼接（配合 MiniMax H3 Director「分段导出」使用）。

导演台用「分段导出」时，每跑完一段就存盘并把上一段从内存里放掉，不会越跑越占内存，
但不会自动拼成一条。这个节点接在导演台的 report 输出后面，导演台跑完后：
  1. 从导演台的分段缓存（output/minimax_seg_cache/<导演台节点号>/）按顺序取出每一段画面和声音
     （本次没重跑的段也在缓存里，所以“选择运行”只重跑几段也能拼出完整版）；
  2. 接缝处用导演台自己“全部导出”时的同一套接缝修正（只动接缝前后几帧）；
  3. 一段一段写进 ffmpeg，内存里最多同时放两段；
  4. 存到 output/H3导演台/<项目名>/v1、v2…：完整版.mp4（内嵌工作流）、工作流.png、字幕、说明.txt。
"""

from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import wave

import torch

import folder_paths
from comfy_api.latest import io

from . import os_subtitles as OSS

DIRECTOR_ROOT = "H3导演台"
SEAM_WIN = 24
SUB_MODES = ["烧进画面 + 出 srt 文件", "只出 srt 文件", "关闭"]


def _director_module(suffix: str):
    """找到已经加载的导演台插件里的某个模块（如 director.segment_continuity）。找不到返回 None。"""
    for name, mod in list(sys.modules.items()):
        f = str(getattr(mod, "__file__", "") or "")
        if name.endswith(suffix) and "MiniMaxH3_Director" in f.replace("\\", "/"):
            return mod
    return None


def _safe(name: str) -> str:
    name = re.sub(r'[\\/:*?"<>|\r\n\t]+', "_", str(name or "")).strip(" .")
    return name or "未命名项目"


def _to_u8(x: torch.Tensor) -> torch.Tensor:
    if x.dtype == torch.uint8:
        return x.contiguous()
    return x.float().clamp(0, 1).mul(255).round().to(torch.uint8).contiguous()


def _load_seg_frames(root: str, idx: int):
    """读一段缓存画面，保持 uint8（省内存）。ffv1 和旧的 .pt 两种存法都能读。"""
    mkv = os.path.join(root, f"seg_{idx:04d}.frames.mkv")
    pt = os.path.join(root, f"seg_{idx:04d}.pt")
    if os.path.isfile(mkv):
        sc = _director_module("director.segment_cache")
        if sc is not None and hasattr(sc, "decode_frames_ffv1"):
            return _to_u8(sc.decode_frames_ffv1(mkv))
    if os.path.isfile(pt):
        return _to_u8(torch.load(pt, map_location="cpu", weights_only=True))
    return None


def _load_seg_audio(root: str, idx: int):
    p = os.path.join(root, f"seg_{idx:04d}.audio.pt")
    if not os.path.isfile(p):
        return None
    try:
        d = torch.load(p, map_location="cpu", weights_only=False)
        w = d.get("waveform") if isinstance(d, dict) else None
        if isinstance(w, torch.Tensor) and w.numel() > 0:
            return w.float(), int(d.get("sample_rate") or 32000)
    except Exception as e:
        print(f"[H3导演台拼接] ⚠️ 第{idx + 1}段声音缓存读不出来：{e}")
    return None


def _read_mp4_frames(path: str):
    """v5.9b：读导演台分段导出的 seg_XXXX.mp4 → uint8 [N,H,W,3]。"""
    import imageio_ffmpeg
    import numpy as np
    gen = imageio_ffmpeg.read_frames(path, pix_fmt="rgb24")
    meta = next(gen)
    w, h = meta["size"]
    frames = [np.frombuffer(f, dtype=np.uint8).reshape(h, w, 3) for f in gen]
    if not frames:
        return None
    return torch.from_numpy(np.stack(frames)).contiguous()


def _read_mp4_audio(path: str, rate: int = 48000):
    """v5.9b：读 mp4 里的声音 → ([2,T] float, rate)；没有声音轨返回 None。"""
    import imageio_ffmpeg
    import numpy as np
    r = subprocess.run([imageio_ffmpeg.get_ffmpeg_exe(), "-v", "error", "-i", path, "-vn",
                        "-f", "f32le", "-ac", "2", "-ar", str(rate), "-"], capture_output=True)
    if r.returncode != 0 or not r.stdout:
        return None
    a = np.frombuffer(r.stdout, dtype=np.float32).reshape(-1, 2).T.copy()
    return torch.from_numpy(a), rate


def _cut_source_audio(path: str, start_s: float, dur_s: float, rate: int = 48000):
    """v5.9c：原声模式时，从时间轴原视频按这段的起止时间直接切声音 → ([2,T] float, rate)。"""
    import imageio_ffmpeg
    import numpy as np
    r = subprocess.run([imageio_ffmpeg.get_ffmpeg_exe(), "-v", "error", "-ss", f"{max(0.0, start_s):.4f}",
                        "-t", f"{max(0.05, dur_s):.4f}", "-i", path, "-vn",
                        "-f", "f32le", "-ac", "2", "-ar", str(rate), "-"], capture_output=True)
    if r.returncode != 0 or not r.stdout:
        return None
    a = np.frombuffer(r.stdout, dtype=np.float32).reshape(-1, 2).T.copy()
    return torch.from_numpy(a), rate


def _fit_audio(w: torch.Tensor, n: int) -> torch.Tensor:
    """[1,C,T] 或 [C,T] → [2,n]：多的裁掉，少的补静音。"""
    if w.ndim == 3:
        w = w[0]
    if w.shape[0] == 1:
        w = w.repeat(2, 1)
    w = w[:2]
    if w.shape[1] >= n:
        return w[:, :n]
    return torch.cat([w, torch.zeros(2, n - w.shape[1])], dim=1)


def _seam_fix(prev_u8: torch.Tensor, cur_u8: torch.Tensor):
    """用导演台“全部导出”时同一套接缝修正，只处理接缝前后 SEAM_WIN 帧。"""
    sc = _director_module("director.segment_continuity")
    if sc is None:
        return "没找到导演台的接缝修正函数，直接首尾相接"
    try:
        k1 = min(SEAM_WIN, prev_u8.shape[0])
        k2 = min(SEAM_WIN, cur_u8.shape[0])
        left = prev_u8[-k1:].float() / 255.0
        body = cur_u8[:k2].float() / 255.0
        left = sc._unfreeze_held_tail(left)
        if getattr(sc, "CONTINUITY_HOLD_POP_ON_TAIL", False):
            left = sc._break_hold_pop_window(left, from_end=True)
        body = sc._break_hold_pop_window(body, from_end=False)
        if float(getattr(sc, "CONTINUITY_SPIKE_WEIGHT", 0) or 0) > 0:
            body = sc._ease_opening_spikes(body)
        body = sc._soften_body0_toward_prev(body, left)
        body = sc._additive_opening_luma(body, left)
        left, body = sc._micro_seam_bridge(left, body)
        if left.shape[0] != k1 or body.shape[0] != k2:
            return "接缝修正改变了帧数，这处直接首尾相接"
        prev_u8[-k1:] = _to_u8(left)
        cur_u8[:k2] = _to_u8(body)
        return ""
    except Exception as e:
        return f"接缝修正出错（{e}），这处直接首尾相接"


def _ffmeta_escape(s: str) -> str:
    return re.sub(r"([=;#\\\n])", r"\\\1", s)


class H3DirectorConcat(io.ComfyNode):
    @classmethod
    def define_schema(cls):
        return io.Schema(
            node_id="H3DirectorConcat",
            display_name="H3 导演台分段拼接（完整版+工作流图+字幕）",
            category="H3 连续镜头批量",
            description="导演台「导出方式」选「分段导出」时用：导演台跑完后，从它的分段缓存把所有段按顺序拼成完整版，"
                        "接缝用导演台同款修正，另存工作流图片和字幕。每次运行新建 v1、v2… 文件夹，不覆盖。",
            is_output_node=True,
            inputs=[
                io.String.Input("report", force_input=True, tooltip="接导演台的 report 输出（保证导演台跑完再拼）"),
                io.String.Input("project", default="", tooltip="项目名＝文件夹名。留空＝用公共参数里图片1的文件名"),
                io.Combo.Input("subtitle_mode", options=SUB_MODES, default=SUB_MODES[0],
                               tooltip="字幕文字取每段提示词里 <d>…</d> 的台词，按人声位置排时间"),
                io.Int.Input("crf", default=17, min=10, max=30, tooltip="画质：数字越小越清晰、文件越大。17 基本看不出损失"),
                io.String.Input("subtitle_styles", default=OSS.DEFAULT_STYLES, multiline=True,
                                tooltip="字幕样式表，一行一种：名称 | 颜色=#RRGGBB | 描边=#RRGGBB | 字号=22 | 位置=底部/顶部/中间 | 边距=7（占画面高度%）"
                                        " | 水平=左/中/右 | 坐标=50,80（直接定位，百分比）。"
                                        "「台词」管 <d> 台词；「内心」管 <os>；<os:名称> 用同名样式。不同样式边距错开就不会挤在同一行。"),
                io.Boolean.Input("clear_old_cache", default=False, label_on="清空", label_off="不清",
                                 tooltip="做新内容时打开：点运行后、导演台开始生成之前，先清空这个导演台的分段缓存"
                                         "（output/minimax_seg_cache/<导演台节点号>），旧项目的段就不会被拼进来。"
                                         "开着的话每次点运行都会清空，第一次跑完新内容后记得关掉，否则之后“选择运行”只重跑几段时，其他段的缓存也会被清掉。"),
            ],
            hidden=[io.Hidden.prompt, io.Hidden.unique_id, io.Hidden.extra_pnginfo],
            outputs=[io.String.Output("file", display_name="完整版路径")],
        )

    # ------------------------------------------------------------ 找导演台和时间轴
    @classmethod
    def _director_info(cls):
        prompt = cls.hidden.prompt or {}
        me = prompt.get(str(cls.hidden.unique_id), {})
        link = (me.get("inputs") or {}).get("report")
        did = str(link[0]) if isinstance(link, list) and link else None
        if did is None or "Director" not in str(prompt.get(did, {}).get("class_type", "")):
            cands = [k for k, v in prompt.items() if v.get("class_type") == "MiniMaxH3Director"]
            did = cands[0] if cands else None
        if did is None:
            raise RuntimeError("没找到导演台节点：请把导演台的 report 输出连到这个节点的 report 口。")
        tl = (prompt[did].get("inputs") or {}).get("timeline_data")
        try:
            tl = json.loads(tl) if isinstance(tl, str) else (tl or {})
        except Exception:
            tl = {}
        return did, tl

    @classmethod
    def _project_name(cls, project: str, tl: dict) -> str:
        if str(project or "").strip():
            return _safe(project)
        g = tl.get("global") or {}
        for r in sorted(g.get("refs") or [], key=lambda r: int(r.get("index", 0))):
            f = r.get("imageFile") or r.get("fileName")
            if f:
                return _safe(os.path.splitext(os.path.basename(f))[0])
        for s in tl.get("segments") or []:
            for r in s.get("refs") or []:
                f = r.get("imageFile") or r.get("fileName")
                if f:
                    return _safe(os.path.splitext(os.path.basename(f))[0])
        return "未命名项目"

    @staticmethod
    def _new_version_dir(project: str) -> str:
        root = os.path.join(folder_paths.get_output_directory(), DIRECTOR_ROOT, project)
        os.makedirs(root, exist_ok=True)
        vs = [int(m.group(1)) for d in os.listdir(root)
              if (m := re.fullmatch(r"v(\d+)", d)) and os.path.isdir(os.path.join(root, d))]
        out = os.path.join(root, f"v{(max(vs) + 1) if vs else 1}")
        os.makedirs(out, exist_ok=False)
        return out

    # ------------------------------------------------------------ 主流程
    @classmethod
    def execute(cls, report, project="", subtitle_mode=SUB_MODES[0], crf=17, subtitle_styles=None, clear_old_cache=False):
        import imageio_ffmpeg
        from PIL import Image
        from PIL.PngImagePlugin import PngInfo

        did, tl = cls._director_info()
        segs = list(tl.get("segments") or [])
        n = len(segs)
        if n == 0:
            raise RuntimeError("导演台时间轴里没有分段。")
        fps = float(tl.get("frameRate") or 24)
        cont = bool((tl.get("output") or {}).get("continuityEnabled"))
        # v5.9c：v2v / rv2v 的「全局」模式下，全局提示词和全局参考图对每段都生效（不看「公共参数」开关）
        video_global = str(tl.get("timelineMode") or "") == "video" and str(tl.get("editMode") or "") == "global"
        audio_mode = str((tl.get("output") or {}).get("audioMode") or "generate").lower()
        src_video = None
        if audio_mode == "source" and str(tl.get("timelineMode") or "") == "video":
            v = tl.get("video") or {}
            if not (v.get("frameMap") or v.get("deletedSourceRanges")):
                try:
                    vio = _director_module("lib.video_io")
                    src_video = vio.resolve_video_path(v) if vio is not None else None
                except Exception:
                    src_video = None
        cache = os.path.join(folder_paths.get_output_directory(), "minimax_seg_cache", did)

        # 本次新生成了哪些段（看导演台这次的分段导出文件夹）
        m = re.search(r"Segment mp4 export dir:\s*(.+)", str(report or ""))
        fresh = []
        export_dir = None
        if m and os.path.isdir(m.group(1).strip()):
            export_dir = m.group(1).strip()
            fresh = sorted(int(x.group(1)) + 1 for f in os.listdir(export_dir)
                           if (x := re.fullmatch(r"seg_(\d+)\.mp4", f)))

        # v5.9b：每段的画面来源。优先导演台缓存；缓存没有（单段、没开段间引导时导演台不写缓存）就用这次分段导出的 mp4；
        src = {}
        for i in range(n):
            if (os.path.isfile(os.path.join(cache, f"seg_{i:04d}.pt"))
                    or os.path.isfile(os.path.join(cache, f"seg_{i:04d}.frames.mkv"))):
                src[i] = "cache"
            elif export_dir and os.path.isfile(os.path.join(export_dir, f"seg_{i:04d}.mp4")):
                src[i] = "mp4"
        missing = [i + 1 for i in range(n) if i not in src]
        # v5.8c：缺的段跳过，只拼已有的段
        use = sorted(src)
        if not use:
            raise RuntimeError("没有能拼的段：导演台缓存里没有，这次也没有分段导出的 mp4。"
                               "请完全重启一次 ComfyUI 再跑（让导演台每段写缓存的补丁需要重启后生效）。")

        def load_frames(i):
            s = src.get(i)
            if s == "cache":
                return _load_seg_frames(cache, i)
            if s == "mp4":
                return _read_mp4_frames(os.path.join(export_dir, f"seg_{i:04d}.mp4"))
            return None

        def load_audio(i, frames):
            # v5.9c：原声模式 → 先用导演台导出的 mp4（已对齐原声），没有就从原视频按时间切；生成声音模式 → 先用缓存
            mp4 = os.path.join(export_dir, f"seg_{i:04d}.mp4") if export_dir else None
            order = ["mp4", "source", "cache"] if audio_mode == "source" else ["cache", "mp4"]
            for k in order:
                a = None
                if k == "cache" and src.get(i) == "cache":
                    a = _load_seg_audio(cache, i)
                elif k == "mp4" and mp4 and os.path.isfile(mp4):
                    a = _read_mp4_audio(mp4)
                elif k == "source" and src_video:
                    a = _cut_source_audio(src_video, float(segs[i].get("start") or 0) / fps, frames / fps)
                if a is not None:
                    return a
            return None

        # 缓存和当前设置对不上的段：提示词改了、或参考图/参考音频换了，但这段没重跑（v5.5 加参考素材检查）
        stale, stale_ref = [], []
        g = tl.get("global") or {}
        common_on = bool(g.get("commonEnabled")) or video_global
        # v5.6：<os> 字幕标记不送模型，比对前先删掉，只改字幕不算“提示词改过”
        common_prompt = OSS.strip_os(str(g.get("prompt") or "").strip()) if common_on else ""
        for i, s in enumerate(segs):
            local = OSS.strip_os(str(s.get("prompt") or "").strip())
            if src.get(i) != "cache":
                continue
            try:
                with open(os.path.join(cache, f"seg_{i:04d}.meta.json"), encoding="utf-8") as f:
                    meta = json.load(f)
            except Exception:
                continue
            mp = str(meta.get("prompt") or "")
            if video_global:
                want_p = local or common_prompt   # 全局模式：本段没写提示词就用全局提示词
                bad = bool(want_p) and OSS.strip_os(want_p) not in mp
            else:
                bad = (local and local not in mp) or (common_prompt and common_prompt not in mp)
            if bad:
                stale.append(i + 1)
            want = _expected_ref_ids(g if common_on else {}, s)
            have = {":".join(str(x).split(":")[:2]) for x in (meta.get("refs") or []) + (meta.get("ref_audios") or [])}
            if want != have:
                stale_ref.append((i + 1, sorted(have - want), sorted(want - have)))

        out_dir = cls._new_version_dir(cls._project_name(project, tl))
        exe = imageio_ffmpeg.get_ffmpeg_exe()

        # 先读第一段确定尺寸，存工作流图片
        first = load_frames(use[0])
        if first is None:
            raise RuntimeError(f"第{use[0] + 1}段画面读不出来。")
        H, W = int(first.shape[1]), int(first.shape[2])
        png = os.path.join(out_dir, "工作流.png")
        info = PngInfo()
        if cls.hidden.prompt is not None:
            info.add_text("prompt", json.dumps(cls.hidden.prompt))
        for k, v in (cls.hidden.extra_pnginfo or {}).items():
            info.add_text(k, json.dumps(v))
        Image.fromarray(first[0].numpy()).save(png, pnginfo=info, compress_level=4)

        # 工作流写进 mp4 元数据（和 VHS 保存视频的做法一样，用元数据文件避免命令行太长）
        meta_txt = os.path.join(out_dir, "_meta.txt")
        comment = json.dumps({"prompt": cls.hidden.prompt, **(cls.hidden.extra_pnginfo or {})}, ensure_ascii=False)
        with open(meta_txt, "w", encoding="utf-8") as f:
            f.write(";FFMETADATA1\ncomment=" + _ffmeta_escape(comment) + "\n")

        # 画面：一段一段写进 ffmpeg；声音：拼成 wav
        wav = os.path.join(out_dir, "_audio.wav")
        video_tmp = os.path.join(out_dir, "_video.mp4")
        proc = subprocess.Popen([exe, "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24",
                                 "-s", f"{W}x{H}", "-r", f"{fps:.6f}", "-i", "-",
                                 "-c:v", "libx264", "-crf", str(int(crf)), "-preset", "medium",
                                 "-pix_fmt", "yuv420p", video_tmp], stdin=subprocess.PIPE, stderr=subprocess.PIPE)
        notes, audio_parts, sr, seg_info = [], [], None, []
        prev, prev_i = None, None
        try:
            for i in use:
                cur = first if i == use[0] else load_frames(i)
                if cur is None:
                    raise RuntimeError(f"第{i + 1}段画面读不出来。")
                if cur.shape[1] != H or cur.shape[2] != W:
                    cur = _to_u8(torch.nn.functional.interpolate(
                        cur.permute(0, 3, 1, 2).float() / 255.0, size=(H, W), mode="bilinear",
                        align_corners=False).permute(0, 2, 3, 1))
                    notes.append(f"第{i + 1}段尺寸和第1段不同，已缩放到 {W}×{H}")
                if prev is not None and prev_i != i - 1:
                    notes.append(f"第{prev_i + 1}段后面直接接第{i + 1}段（中间的段还没跑），这里会跳一下")
                if prev is not None and cont and prev_i == i - 1:
                    msg = _seam_fix(prev, cur)
                    if msg:
                        notes.append(f"第{i}→{i + 1}段：{msg}")
                if prev is not None:
                    proc.stdin.write(prev.numpy().tobytes())
                frames = int(cur.shape[0])
                a = load_audio(i, frames)
                if a is not None and sr is None:
                    sr = a[1]
                rate = sr or 32000
                nsamp = int(round(frames / fps * rate))
                if a is None:
                    notes.append(f"第{i + 1}段没有声音，补静音")
                    audio_parts.append(torch.zeros(2, nsamp))
                else:
                    w, r0 = a
                    if r0 != rate:
                        w = torch.nn.functional.interpolate(w.reshape(1, -1, w.shape[-1]),
                                                            size=int(w.shape[-1] * rate / r0), mode="linear")
                    audio_parts.append(_fit_audio(w, nsamp))
                seg_prompt = segs[i].get("prompt") or ""
                seg_info.append((i, frames, dialog_lines_safe(seg_prompt), seg_prompt))
                prev, prev_i = cur, i
            proc.stdin.write(prev.numpy().tobytes())
            proc.stdin.close()
            err = proc.stderr.read().decode("utf-8", "ignore")
            if proc.wait() != 0:
                raise RuntimeError("ffmpeg 写画面失败：" + err[-400:])
        except Exception:
            try:
                proc.kill()
            except Exception:
                pass
            raise
        finally:
            prev = cur = first = None

        audio = torch.cat(audio_parts, dim=1).clamp(-1, 1)
        rate = sr or 32000
        with wave.open(wav, "wb") as wf:
            wf.setnchannels(2)
            wf.setsampwidth(2)
            wf.setframerate(rate)
            wf.writeframes((audio.t().numpy() * 32767).astype("int16").tobytes())

        out = os.path.join(out_dir, "完整版.mp4")
        r = subprocess.run([exe, "-y", "-loglevel", "error", "-i", video_tmp, "-i", wav, "-i", meta_txt,
                            "-map", "0:v", "-map", "1:a", "-map_metadata", "2", "-c:v", "copy",
                            "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", out],
                           capture_output=True, text=True, timeout=1800)
        if r.returncode != 0:
            raise RuntimeError("ffmpeg 合并声音失败：" + r.stderr[-400:])
        for f in (video_tmp, meta_txt):
            try:
                os.remove(f)
            except OSError:
                pass

        sub_note = cls._subtitles(out_dir, out, wav, rate, fps, seg_info, subtitle_mode, exe,
                                  subtitle_styles, W, H,
                                  global_prompt=str(g.get("prompt") or "") if video_global else "")
        try:
            os.remove(wav)
        except OSError:
            pass

        total = sum(x[1] for x in seg_info)
        lines = [f"导演台节点 #{did} · 时间轴共 {n} 段 · 这次拼了 {len(use)} 段：第 {'、'.join(str(i + 1) for i in use)} 段"
                 f" · {total} 帧（约 {total / fps:.1f} 秒）· {W}×{H}",
                 "本次新生成的段：" + ("、".join(map(str, fresh)) if fresh else "没有（全部来自缓存）"),
                 "每段帧数：" + "  ".join(f"第{x[0] + 1}段 {x[1]}" for x in seg_info)]
        if missing:
            lines.append(f"还没跑、这次没拼的段：第 {'、'.join(map(str, missing))} 段")
        from_mp4 = [i + 1 for i in use if src[i] == "mp4"]
        if from_mp4:
            lines.append(f"第 {'、'.join(map(str, from_mp4))} 段导演台没写缓存（单段或没开段间引导时会这样），取自这次分段导出的 mp4")
        if stale:
            lines.append(f"⚠️ 第 {'、'.join(map(str, stale))} 段：提示词改过但缓存还是旧的（没重跑），完整版里用的是旧画面")
        for idx, old, new in stale_ref:
            lines.append(f"⚠️ 第 {idx} 段：参考素材换过但缓存还是旧的（没重跑）。缓存用的：{'、'.join(old) or '无'}；现在设置的：{'、'.join(new) or '无'}")
        lines += notes
        if sub_note:
            lines.append(sub_note)
        with open(os.path.join(out_dir, "说明.txt"), "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")
        print("[H3导演台拼接] 完整版：" + out + "\n  " + "\n  ".join(lines))
        return io.NodeOutput(out)

    # ------------------------------------------------------------ 字幕（台词按人声位置排；v5.6 加 <os> 多条字幕 + 样式表）
    @classmethod
    def _subtitles(cls, out_dir, video, wav_path, rate, fps, seg_info, mode, exe, styles_text=None, W=0, H=0,
                   global_prompt=""):
        if mode == SUB_MODES[2]:
            return ""
        try:
            from . import nodes as N
            import numpy as np
        except Exception as e:
            return f"字幕跳过：{e}"
        try:
            r = subprocess.run([exe, "-v", "error", "-i", wav_path, "-ac", "1", "-ar", "16000", "-f", "s16le", "-"],
                               capture_output=True, timeout=300)
            mono = np.frombuffer(r.stdout, dtype=np.int16).astype("float32") / 32768.0
        except Exception as e:
            return f"字幕跳过：读声音失败 {e}"
        cues, os_list, t = [], [], 0.0
        for info in seg_info:
            i, frames, lines = info[0], info[1], info[2]
            seg_prompt = info[3] if len(info) > 3 else ""
            dur = frames / fps
            spans = []
            if lines and dur > 0.6:
                part = mono[int(t * 16000): int((t + dur) * 16000)]
                try:
                    groups = N.utterances(N.speech_spans(part), len(lines))
                except Exception:
                    groups = []
                for k, line in enumerate(lines):
                    pieces = N.split_caption(line)
                    if not pieces:
                        spans.append(None)
                        continue
                    if len(groups) == len(lines):
                        placed = N.place_pieces(pieces, groups[k])
                    else:
                        segd = (dur - 0.25) / len(lines)
                        placed = N.place_pieces(pieces, [(0.15 + k * segd, 0.15 + (k + 1) * segd)])
                    mine = []
                    for a, b, x in placed:
                        c = [t + max(0.0, a - 0.08), t + min(dur - 0.04, b + 0.25), x]
                        cues.append(c)
                        mine.append(c)
                    spans.append((mine[0][0], mine[-1][1]) if mine else None)
            if seg_prompt and "<os" in seg_prompt.lower():
                try:
                    os_list += OSS.os_cues(seg_prompt, t, dur, spans)
                except Exception as e:
                    print(f"[H3导演台拼接] ⚠️ 第{i + 1}段 <os> 字幕没排上：{e}")
            t += dur
        # v5.9c：v2v / rv2v 全局模式的全局提示词里的 <os> 字幕，t= 按整条视频的时间算（只排一次，不按段重复）
        if global_prompt and "<os" in global_prompt.lower():
            try:
                os_list += OSS.os_cues(global_prompt, 0.0, t, [])
            except Exception as e:
                print(f"[H3导演台拼接] ⚠️ 全局提示词的 <os> 字幕没排上：{e}")
        cues.sort(key=lambda c: c[0])
        for i in range(len(cues) - 1):
            cues[i][1] = min(cues[i][1], cues[i + 1][0] - 0.02)
        if not cues and not os_list:
            return "提示词里没有 <d>…</d> 台词，也没有 <os> 字幕，没生成字幕"
        notes = []
        # v5.9c：<os:台词 …> 写的台词字幕也进 完整版.srt
        srt_cues = sorted([list(c) for c in cues] + [[a, b, x] for a, b, x, st in os_list if st == OSS.DIALOG_STYLE],
                          key=lambda c: c[0])
        if srt_cues:
            srt = "\n".join(f"{i}\n{N.srt_time(a)} --> {N.srt_time(b)}\n{x}\n" for i, (a, b, x) in enumerate(srt_cues, start=1))
            with open(os.path.join(out_dir, "完整版.srt"), "w", encoding="utf-8-sig") as f:
                f.write(srt)
            notes.append(f"完整版.srt（台词 {len(srt_cues)} 条）")
        all_cues = OSS.trim_same_style([[a, b, x, OSS.DIALOG_STYLE] for a, b, x in cues] + os_list)
        os_names = sorted({c[3] for c in all_cues if c[3] != OSS.DIALOG_STYLE})
        for name in os_names:   # 每种 <os> 样式另出一个 srt，方便剪映里单独一轨
            mine = [c for c in all_cues if c[3] == name]
            srt = "\n".join(f"{i}\n{N.srt_time(a)} --> {N.srt_time(b)}\n{x}\n" for i, (a, b, x, _) in enumerate(mine, start=1))
            with open(os.path.join(out_dir, f"完整版_{_safe(name)}.srt"), "w", encoding="utf-8-sig") as f:
                f.write(srt)
            notes.append(f"完整版_{name}.srt（{len(mine)} 条）")
        styles = OSS.parse_styles(styles_text if styles_text is not None else OSS.DEFAULT_STYLES)
        ass = OSS.build_ass(all_cues, styles, W or 960, H or 640)
        with open(os.path.join(out_dir, "完整版_全部字幕.ass"), "w", encoding="utf-8-sig") as f:
            f.write(ass)
        notes.append("完整版_全部字幕.ass（所有字幕和样式）")
        unknown = [n for n in os_names if n not in styles]
        if unknown:
            notes.append(f"⚠️ 样式表里没有：{'、'.join(unknown)}，先用「{OSS.DEFAULT_OS_STYLE}」样式显示")
        if mode != SUB_MODES[0]:
            return "字幕：" + "、".join(notes)
        with open(os.path.join(out_dir, "_subs.ass"), "w", encoding="utf-8") as f:
            f.write(ass)
        r = subprocess.run([exe, "-y", "-loglevel", "error", "-i", os.path.basename(video),
                            "-vf", "subtitles=_subs.ass",
                            "-c:v", "libx264", "-crf", "17", "-preset", "medium", "-pix_fmt", "yuv420p",
                            "-c:a", "copy", "-map_metadata", "0", "完整版_字幕.mp4"],
                           capture_output=True, text=True, timeout=3600, cwd=out_dir)
        try:
            os.remove(os.path.join(out_dir, "_subs.ass"))
        except OSError:
            pass
        if r.returncode != 0:
            return "字幕烧进画面失败，只保留了字幕文件（" + "、".join(notes) + "）：" + r.stderr[-200:]
        return "字幕：" + "、".join(notes) + " + 完整版_字幕.mp4"


def _expected_ref_ids(g: dict, s: dict) -> set:
    """按导演台规则（公共 + 本组，同编号以本组为准）算出这段现在应该用的参考图/参考音频，格式同缓存 meta：img0:文件名 / aud0:文件名。"""
    out = set()
    for kind, key, fkey in (("img", "refs", "imageFile"), ("aud", "refAudios", "audioFile")):
        d = {}
        for src in (g.get(key) or [], s.get(key) or []):
            for r in src:
                if isinstance(r, dict):
                    f = str(r.get(fkey) or r.get("fileName") or "").replace("\\", "/").strip()
                    if f:
                        d[int(r.get("index", r.get("slot", 0)))] = f
        out |= {f"{kind}{i}:{f}" for i, f in d.items()}
    return out


def dialog_lines_safe(text: str) -> list[str]:
    try:
        from . import nodes as N
        return N.dialog_lines(text)
    except Exception:
        return [re.sub(r"\s+", " ", x).strip() for x in re.findall(r"<d>\s*(?:\[[^\]]*\])?\s*(.*?)</d>", text or "", re.S)
                if x.strip()]


# ---------------------------------------------------------------- 「运行前清空旧缓存」开关（v5.8b）
def _force_director_cache():
    """v5.9b：导演台原本只在多段/开段间引导/开精修时才写分段缓存，单段时不写，拼接就拿不到画面。
    工作流里有拼接节点时，让导演台每次都写缓存（「分段导出」「全部导出」都一样），拼接节点就总能拼。
    导演台被热重载后模块是新的，下次点运行会自动再打一次补丁。"""
    ec = _director_module("director.executor_core")
    if ec is None or getattr(ec, "_h3bs_cache_forced", False) or not hasattr(ec, "_segment_disk_cache_needed"):
        return
    ec._segment_disk_cache_needed = lambda *a, **k: True
    ec._h3bs_cache_forced = True
    print("[H3导演台拼接] 已让导演台每段都写缓存（单段也能拼）")


def _clear_cache_on_prompt(json_data):
    """点运行时（导演台还没开始生成）检查：拼接节点开了 clear_old_cache，就清空它连着的导演台的分段缓存。"""
    try:
        prompt = json_data.get("prompt") or {}
        if any(v.get("class_type") == "H3DirectorConcat" for v in prompt.values() if isinstance(v, dict)):
            try:
                _force_director_cache()
            except Exception as e:  # noqa: BLE001
                print(f"[H3导演台拼接] ⚠️ 没能让导演台写缓存：{e}")
        for nid, node in prompt.items():
            if node.get("class_type") != "H3DirectorConcat":
                continue
            ins = node.get("inputs") or {}
            if not ins.get("clear_old_cache"):
                continue
            link = ins.get("report")
            did = str(link[0]) if isinstance(link, list) and link else None
            if did is None:
                continue
            sc = _director_module("director.segment_cache")
            if sc is not None and hasattr(sc, "clear_segment_cache"):
                n = sc.clear_segment_cache(did, kind="all")
            else:
                root = os.path.join(folder_paths.get_output_directory(), "minimax_seg_cache", did)
                n = 0
                if os.path.isdir(root):
                    for f in os.listdir(root):
                        fp = os.path.join(root, f)
                        if os.path.isfile(fp):
                            os.remove(fp)
                            n += 1
            print(f"[H3导演台拼接] 已按开关清空导演台 #{did} 的旧分段缓存（{n} 个文件）")
    except Exception as e:  # noqa: BLE001
        print(f"[H3导演台拼接] ⚠️ 清空旧缓存失败：{e}")
    return json_data


def register_clear_cache_hook():
    try:
        from server import PromptServer
        PromptServer.instance.add_on_prompt_handler(_clear_cache_on_prompt)
    except Exception as e:  # noqa: BLE001
        print(f"[H3导演台拼接] ⚠️ 没能注册「清空旧缓存」开关：{e}")
