"""H3 连续镜头批量（ComfyUI-H3-BatchShots）

给 MiniMax H3 官方工作流用的 3 个小节点：
  1. H3 分镜表      —— 按序号取出当前镜头的提示词 / 时长 / 种子 / 画面尺寸，自动加 LoRA 触发词
  2. H3 自动衔接    —— 第 1 镜用首帧图；之后每镜自动读取上一镜结尾几帧（含声音）做无缝衔接
  3. H3 保存镜头    —— 裁掉衔接帧、对齐上一镜颜色、保存、自动拼接完整版、清理显存

用法：在“运行”按钮旁把批次数量设为镜头数，点一次运行即可整夜自动跑完。
v5.6：导演台提示词里的 <os>…</os> 字幕标记在送模型前自动删掉（见 os_subtitles.py）。
v5.7：导演台节点右键「从分镜 txt 导入」（见 web/h3_storyboard_import.js）。
v5.8b：拼接节点加「运行前清空旧缓存」开关（v5.8/v5.9 的缓存核对已撤回）。
v5.9d：导演台「分组 LoRA」只看指定文件夹的 LoRA（见 director_lora_filter.py），LoRA 多时不再卡。
"""

from .nodes import comfy_entrypoint  # noqa: F401
from .os_subtitles import register_prompt_hook

register_prompt_hook()

from .director_concat import register_clear_cache_hook

register_clear_cache_hook()

from .director_lora_filter import register_routes as _register_lora_filter, keywords as _lora_kws

_register_lora_filter()
_lora_kws()  # 首次运行时生成「导演台LoRA只看这些文件夹.txt」

WEB_DIRECTORY = "./web"

__all__ = ["comfy_entrypoint", "WEB_DIRECTORY"]
