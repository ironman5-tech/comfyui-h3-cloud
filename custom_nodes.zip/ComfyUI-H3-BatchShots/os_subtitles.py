"""v5.6：多条字幕（台词 + 内心OS / 旁白 / 其他角色）。

提示词写法（导演台素材组 / 公共提示词里都能写）：
  <os>*不适合你。</os>              内心字幕，用「内心」样式
  <os:顾客>：我就喜欢这个</os>      用样式表里名叫「顾客」的样式（名字随便起，样式表里加一行即可）
  <os t=0-1.5>*客人来了</os>        指定这一段里第 0～1.5 秒显示（秒数从本段开头算）
  <os:顾客 t=2-4>…</os>             样式和时间可以一起写

没写 t= 时自动排时间：
  · 跟着它后面最近的一句 <d>台词</d> 一起出现，一直显示到下一个 <os> 之前的那句台词说完；
  · 后面没有台词了（写在本段所有台词之后）→ 最后一句台词说完后出现，显示 2 秒；
  · 想在没人说话的空档出现（比如开头、两句台词之间的停顿），用 t= 指定秒数。

<os>…</os> 只用来出字幕：导演台把提示词送给模型之前会自动删掉，模型看不到，也不会算作“提示词改过”。
"""

from __future__ import annotations

import functools
import logging
import re
import sys

log = logging.getLogger("H3BatchShots")

OS_RE = re.compile(r"<os\b([^>]*)>(.*?)</os>", re.S | re.I)
TOKEN_RE = re.compile(r"<os\b([^>]*)>(.*?)</os>|<d>\s*(?:\[[^\]]*\]\s*)?(.*?)</d>", re.S | re.I)

DEFAULT_OS_STYLE = "内心"
DIALOG_STYLE = "台词"

# 每行一个样式：名称 | 参数=值 | …
#   颜色 / 描边：#RRGGBB；字号：数字（画面高 288 时的大小，和旧版字幕同一标准）
#   位置：底部 / 顶部 / 中间；边距：离那条边的距离，占画面高度的百分比
#   水平：左 / 中 / 右；坐标=x,y：直接放到画面百分比坐标（例 50,80），写了它就不管位置/边距
DEFAULT_STYLES = """台词 | 颜色=#FFFFFF | 描边=#202020 | 字号=22 | 位置=底部 | 边距=7
内心 | 颜色=#FFE45C | 描边=#202020 | 字号=21 | 位置=底部 | 边距=16
顾客 | 颜色=#FFFFFF | 描边=#6B4E00 | 字号=20 | 位置=底部 | 边距=25"""


# ---------------------------------------------------------------- 送模型前删标记
def strip_os(text):
    if not isinstance(text, str) or "<os" not in text.lower():
        return text
    t = OS_RE.sub("", text)
    t = re.sub(r"[ \t]{2,}", " ", t)
    t = re.sub(r"[ \t]+\n", "\n", t)
    t = re.sub(r"[ \t]+([,.;:!?])", r"\1", t)
    return t.strip()


def _parse_attrs(s: str):
    s = (s or "").strip()
    style, t = None, None
    m = re.match(r"^[:：]\s*([^\s=]+)", s)
    if m:
        style, s = m.group(1), s[m.end():]
    for k, v in re.findall(r"(\w+)\s*=\s*[\"']?([^\"'\s]+)[\"']?", s):
        if k in ("style", "样式"):
            style = v
        elif k in ("t", "时间"):
            mm = re.match(r"([\d.]+)\s*[-~～]\s*([\d.]+)", v)
            if mm:
                t = (float(mm.group(1)), float(mm.group(2)))
    return style, t


def tokens(prompt: str):
    """按出现顺序返回 [("d", 台词) | ("os", 文字, 样式, 时间)]；台词规则和 dialog_lines 一致（空台词跳过）。"""
    out = []
    for m in TOKEN_RE.finditer(prompt or ""):
        if m.group(3) is not None:
            x = re.sub(r"\s+", " ", m.group(3)).strip()
            if x:
                out.append(("d", x))
        else:
            x = re.sub(r"\s+", " ", m.group(2)).strip()
            if x:
                style, t = _parse_attrs(m.group(1))
                out.append(("os", x, style, t))
    return out


def os_cues(prompt: str, t0: float, dur: float, line_spans: list, default_len: float = 2.0):
    """算本段 <os> 字幕的时间。line_spans[k] = 第 k 句台词的 (开始, 结束)，绝对秒数。返回 [[开始, 结束, 文字, 样式]]。"""
    items, di = [], 0
    for tok in tokens(prompt):
        if tok[0] == "d":
            di += 1
        else:
            items.append((tok[1], tok[2], tok[3], di))
    nd = di
    spans = list(line_spans) + [None] * max(0, nd - len(line_spans))
    res = []
    for j, (text, style, t, k) in enumerate(items):
        if t:
            a, b = t0 + t[0], t0 + t[1]
        else:
            if k < nd and spans[k]:
                a = spans[k][0]
            elif k > 0 and spans[k - 1]:
                a = spans[k - 1][1]
            else:
                a = t0 + 0.15
            nxt = items[j + 1][3] if j + 1 < len(items) else nd
            if nxt > k and spans[nxt - 1]:
                b = spans[nxt - 1][1] + 0.3
            else:
                b = a + default_len
            b = max(b, a + 1.2)
        a, b = max(t0, a), min(t0 + dur - 0.04, b)
        if b - a > 0.2:
            res.append([a, b, text, style or DEFAULT_OS_STYLE])
    return res


# ---------------------------------------------------------------- 样式表 → ASS
def _ass_color(hexs: str, alpha: int = 0) -> str:
    h = (hexs or "").strip().lstrip("#")
    if not re.fullmatch(r"[0-9a-fA-F]{6}", h):
        h = "FFFFFF"
    r, g, b = h[0:2], h[2:4], h[4:6]
    return f"&H{alpha:02X}{b}{g}{r}".upper()


def parse_styles(text: str) -> dict:
    styles = {}
    for raw in (text or "").splitlines():
        raw = raw.strip()
        if not raw or raw.startswith("#"):
            continue
        parts = [p.strip() for p in re.split(r"[|｜]", raw)]
        name = parts[0]
        if not name:
            continue
        kv = {}
        for p in parts[1:]:
            if "=" in p or "＝" in p:
                k, v = re.split(r"[=＝]", p, 1)
                kv[k.strip()] = v.strip()
        styles[name] = kv
    for k, v in parse_styles_defaults().items():
        styles.setdefault(k, v)
    return styles


@functools.lru_cache(maxsize=1)
def _defaults_cached():
    out = {}
    for raw in DEFAULT_STYLES.splitlines():
        parts = [p.strip() for p in raw.split("|")]
        out[parts[0]] = dict(p.split("=", 1) for p in parts[1:])
    return out


def parse_styles_defaults() -> dict:
    return {k: dict(v) for k, v in _defaults_cached().items()}


def _num(v, d):
    try:
        return float(str(v).replace("%", ""))
    except Exception:
        return d


def _ass_time(t: float) -> str:
    t = max(0.0, t)
    cs = int(round(t * 100))
    h, cs = divmod(cs, 360000)
    m, cs = divmod(cs, 6000)
    s, cs = divmod(cs, 100)
    return f"{h}:{m:02d}:{s:02d}.{cs:02d}"


def _ass_text(x: str) -> str:
    return x.replace("\\", "＼").replace("{", "（").replace("}", "）").replace("\n", "\\N")


def build_ass(cues: list, styles: dict, width: int, height: int) -> str:
    """cues: [[开始, 结束, 文字, 样式名]]。字号按画面短边算：横版短边=288（和旧版 srt 字幕一样大），
    竖版短边=320（字略小一点，14 个字一行放得下）。"""
    width, height = max(1, int(width)), max(1, int(height))
    short = 288 if width >= height else 320
    if width >= height:
        pry, prx = short, max(1, int(round(short * width / height)))
    else:
        prx, pry = short, max(1, int(round(short * height / width)))
    used = sorted({c[3] for c in cues} | {DIALOG_STYLE})
    lines = ["[Script Info]", "ScriptType: v4.00+", f"PlayResX: {prx}", f"PlayResY: {pry}",
             "WrapStyle: 0", "ScaledBorderAndShadow: yes", "Collisions: Normal", "",
             "[V4+ Styles]",
             "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, "
             "Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, "
             "MarginR, MarginV, Encoding"]
    pos_tags = {}
    for name in used:
        kv = styles.get(name) or styles.get(DEFAULT_OS_STYLE) or {}
        size = _num(kv.get("字号"), 22)
        where = kv.get("位置", "底部")
        horiz = kv.get("水平", "中")
        row = {"底部": 0, "中间": 3, "顶部": 6}.get(where, 0)
        col = {"左": 1, "中": 2, "右": 3}.get(horiz, 2)
        align = row + col
        mv = int(round(_num(kv.get("边距"), 7) / 100 * pry))  # 边距按画面高度百分比
        lines.append(f"Style: {name},{kv.get('字体', 'Microsoft YaHei')},{size:g},{_ass_color(kv.get('颜色', '#FFFFFF'))},"
                     f"&H00FFFFFF,{_ass_color(kv.get('描边', '#202020'))},&H96000000,-1,0,0,0,100,100,0.5,0,1,"
                     f"{_num(kv.get('描边粗细'), 1.4):g},1.2,{align},12,12,{mv},1")
        xy = kv.get("坐标")
        if xy and re.fullmatch(r"\s*[\d.]+\s*[,，]\s*[\d.]+\s*", xy):
            x, y = [float(v) for v in re.split(r"[,，]", xy)]
            pos_tags[name] = "{\\an5\\pos(%d,%d)}" % (round(x / 100 * prx), round(y / 100 * pry))
    lines += ["", "[Events]", "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text"]
    for a, b, x, name in sorted(cues, key=lambda c: c[0]):
        st = name if name in used else DEFAULT_OS_STYLE
        lines.append(f"Dialogue: 0,{_ass_time(a)},{_ass_time(b)},{st},,0,0,0,,{pos_tags.get(st, '')}{_ass_text(x)}")
    return "\n".join(lines) + "\n"


def trim_same_style(cues: list) -> list:
    """同一样式的字幕不重叠：前一条在后一条出现前结束。"""
    cues = sorted(cues, key=lambda c: c[0])
    last = {}
    for c in cues:
        p = last.get(c[3])
        if p is not None and p[1] > c[0] - 0.02:
            p[1] = max(p[0] + 0.1, c[0] - 0.02)
        last[c[3]] = c
    return [c for c in cues if c[1] - c[0] > 0.1]


# ---------------------------------------------------------------- 给导演台装“送模型前删 <os>”
def _wrap_plan(fn):
    if getattr(fn, "_h3_os_wrapped", False):
        return fn

    @functools.wraps(fn)
    def wrapper(*a, **k):
        plan = fn(*a, **k)
        try:
            for s in getattr(plan, "segments", None) or []:
                if isinstance(getattr(s, "prompt", None), str):
                    s.prompt = strip_os(s.prompt)
            if isinstance(getattr(plan, "global_prompt", None), str):
                plan.global_prompt = strip_os(plan.global_prompt)
        except Exception as e:  # noqa: BLE001
            log.warning("[H3BatchShots] 删 <os> 标记失败（不影响生成）：%s", e)
        return plan

    wrapper._h3_os_wrapped = True
    return wrapper


def _wrap_cond(fn):
    if getattr(fn, "_h3_os_wrapped", False):
        return fn

    @functools.wraps(fn)
    def wrapper(*a, **k):
        if isinstance(k.get("prompt"), str):
            k["prompt"] = strip_os(k["prompt"])
        return fn(*a, **k)

    wrapper._h3_os_wrapped = True
    return wrapper


def install_director_patch() -> int:
    """在已加载的 MiniMax H3 导演台模块上包一层：分段计划和送模型的提示词都先删掉 <os>…</os>。不改导演台文件。"""
    n = 0
    for _name, mod in list(sys.modules.items()):
        f = str(getattr(mod, "__file__", "") or "").replace("\\", "/")
        if "MiniMaxH3_Director" not in f:
            continue
        for attr in ("prepare_director_plan", "build_director_plan"):
            fn = getattr(mod, attr, None)
            if callable(fn) and not getattr(fn, "_h3_os_wrapped", False):
                setattr(mod, attr, _wrap_plan(fn))
                n += 1
        fn = getattr(mod, "run_minimax_conditioning", None)
        if callable(fn) and not getattr(fn, "_h3_os_wrapped", False):
            setattr(mod, "run_minimax_conditioning", _wrap_cond(fn))
            n += 1
    return n


def register_prompt_hook():
    """每次点运行时（导演台已加载）检查一次补丁，所以和插件加载顺序无关。"""
    try:
        from server import PromptServer

        def _hook(json_data):
            try:
                k = install_director_patch()
                if k:
                    print(f"[H3BatchShots] 已给导演台装上 <os> 字幕标记过滤（{k} 处）")
            except Exception as e:  # noqa: BLE001
                print(f"[H3BatchShots] ⚠️ <os> 过滤没装上：{e}")
            return json_data

        PromptServer.instance.add_on_prompt_handler(_hook)
    except Exception as e:  # noqa: BLE001
        print(f"[H3BatchShots] ⚠️ 没能注册 <os> 过滤：{e}")
