"""段间衔接防偏色（参考「SelfLift 双采无缝无色差长视频」工作流的做法）。

原来的问题：
  导演台把上一段生成出来的原始数据（latent）直接钉进下一段。上一段里的一点点
  发白、过锐、过饱和会原样传给下一段，下一段又在此基础上再偏一点，越往后越严重。

现在的做法（两步）：
  1. 钉帧换成“画面重新编码”：取上一段已经对过颜色的成片画面的最后几帧，
     除最后一帧外加一点轻微噪声，再用 VAE 重新编码后钉进下一段。
     每段都从干净的画面重新开始，误差不会一段接一段地累积。
  2. 每段生成后做一次颜色对齐（mkl_lab）：用这一段开头第一帧和上一段最后一帧
     算出一个固定的颜色变换，统一套用到这一段所有帧上。
     对齐后的画面才保存，也才拿去给下一段当钉帧，所以颜色一直跟着第一段走。

想关掉这套做法、回到导演台原来的方式：把 PIXEL_RESET_ENABLED 改成 False，重启 ComfyUI。
"""

from __future__ import annotations

import logging

import torch

log = logging.getLogger("ComfyUI-MiniMaxH3-Director.pixel_reset")

# 总开关：True = 用画面重新编码钉帧 + 每段颜色对齐；False = 导演台原来的方式
PIXEL_RESET_ENABLED = True
# 钉帧前给前面几帧加的噪声强度（最后一帧不加）。参考工作流用 0.1
PIN_NOISE_STRENGTH = 0.10
# 颜色对齐强度。参考工作流用 0.75；1.0 = 完全对齐，0 = 不对齐
COLOR_MATCH_STRENGTH = 0.75


def build_pin_frames(prev_export: torch.Tensor, context_frames: int) -> torch.Tensor:
    """取上一段成片的最后 N 帧，除最后一帧外加轻微噪声。

    最后一帧保持干净，让新一段的开头和上一段的结尾严格接上；
    前面几帧加噪声，是为了让模型只把它们当作动作参考，减少接缝闪烁。
    """
    frames = prev_export[..., :3].detach().float().cpu()
    n = max(1, min(int(context_frames), int(frames.shape[0])))
    tail = frames[-n:].clone()
    if n > 1 and PIN_NOISE_STRENGTH > 0:
        generator = torch.manual_seed(0)
        noise = torch.randn(tail[:-1].shape, generator=generator)
        tail[:-1] = (tail[:-1] + PIN_NOISE_STRENGTH * noise).clamp(0.0, 1.0)
    return tail


def _mkl_matrix(cov_source: torch.Tensor, cov_ref: torch.Tensor, eps: float = 1e-6) -> torch.Tensor:
    """MKL 颜色变换矩阵（与 ComfyUI 自带「Transfer Color」节点的 mkl_lab 算法相同）。"""
    eig_val_s, eig_vec_s = torch.linalg.eigh(cov_source)
    sqrt_val_s = torch.sqrt(eig_val_s.clamp_min(0)).clamp_min_(eps)
    scaled_v = eig_vec_s * sqrt_val_s.unsqueeze(0)
    middle = scaled_v.T @ cov_ref @ scaled_v
    eig_val_m, eig_vec_m = torch.linalg.eigh(middle)
    sqrt_m = torch.sqrt(eig_val_m.clamp_min(0))
    inv_scaled_v = eig_vec_s * (1.0 / sqrt_val_s).unsqueeze(0)
    m_half = (eig_vec_m * sqrt_m.unsqueeze(0)) @ eig_vec_m.T
    return inv_scaled_v @ m_half @ inv_scaled_v.T


def _lab_stats(lab_flat: torch.Tensor):
    mean = lab_flat.mean(dim=-1, keepdim=True)
    centered = lab_flat - mean
    return mean, centered @ centered.T / lab_flat.shape[-1]


def match_segment_colors(chunk: torch.Tensor, prev_export: torch.Tensor) -> torch.Tensor:
    """用本段第一帧和上一段最后一帧算颜色变换，统一套用到本段所有帧。"""
    if COLOR_MATCH_STRENGTH <= 0 or chunk is None or prev_export is None:
        return chunk
    if int(chunk.shape[0]) < 1 or int(prev_export.shape[0]) < 1:
        return chunk
    try:
        import kornia
        import comfy.model_management as mm

        device = mm.get_torch_device()
        ref = prev_export[-1:, ..., :3].to(device, dtype=torch.float32)
        src0 = chunk[:1, ..., :3].to(device, dtype=torch.float32)
        if tuple(ref.shape[1:3]) != tuple(src0.shape[1:3]):
            ref = torch.nn.functional.interpolate(
                ref.permute(0, 3, 1, 2), size=tuple(src0.shape[1:3]), mode="bilinear", align_corners=False
            ).permute(0, 2, 3, 1)
        ref_lab = kornia.color.rgb_to_lab(ref.permute(0, 3, 1, 2)).view(3, -1)
        src_lab = kornia.color.rgb_to_lab(src0.permute(0, 3, 1, 2)).view(3, -1)
        ref_mean, ref_cov = _lab_stats(ref_lab)
        src_mean, src_cov = _lab_stats(src_lab)
        transform = _mkl_matrix(src_cov, ref_cov)

        out = chunk.clone()
        height, width = int(chunk.shape[1]), int(chunk.shape[2])
        for i in range(int(chunk.shape[0])):
            frame = chunk[i : i + 1, ..., :3].to(device, dtype=torch.float32)
            lab = kornia.color.rgb_to_lab(frame.permute(0, 3, 1, 2)).view(3, -1)
            matched_lab = transform @ (lab - src_mean) + ref_mean
            matched = kornia.color.lab_to_rgb(matched_lab.view(1, 3, height, width)).permute(0, 2, 3, 1)
            blended = frame + COLOR_MATCH_STRENGTH * (matched - frame)
            out[i : i + 1, ..., :3] = blended.clamp(0.0, 1.0).to(out.device, dtype=out.dtype)
        log.info("段间防偏色：本段 %d 帧已按上一段结尾做颜色对齐（mkl_lab，强度 %.2f）",
                 int(chunk.shape[0]), COLOR_MATCH_STRENGTH)
        return out
    except Exception as exc:  # 颜色对齐失败时不影响出片，只是这段不对齐
        log.warning("段间防偏色：颜色对齐失败，这一段保持原样（%s: %s）", type(exc).__name__, exc)
        return chunk
